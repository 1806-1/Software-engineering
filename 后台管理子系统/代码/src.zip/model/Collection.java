package model;

public class Collection {
	private int id;
	private String museumName;
	private String type;
	private String colname;
	private String introduction;
	private String photo;
	private int status;

	@Override
	public String toString() {
		return "Collection{" +
				"id=" + id +
				", museumName='" + museumName + '\'' +
				", type='" + type + '\'' +
				", colname='" + colname + '\'' +
				", introduction='" + introduction + '\'' +
				", photo='" + photo + '\'' +
				", status=" + status +
				'}';
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMuseumName() {
		return museumName;
	}

	public void setMuseumName(String museumName) {
		this.museumName = museumName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getColname() {
		return colname;
	}

	public void setColname(String colname) {
		this.colname = colname;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
