package com.example.login1.ui.my_page;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.login1.R;
import com.example.login1.ui.login.LoginActivity;
import com.example.login1.ui.register.RegisterActivity;

public class MyPageActivity extends AppCompatActivity {

    //声明控件
    private Button myCommentsButton;   //“我的评论”按钮
    private Button myExplainButton;  //“我的讲解”按钮
    private Button myInformationButton; //“个人信息”按钮

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_page);

        //找到控件
        myCommentsButton = findViewById(R.id.button_my_comments);
        myExplainButton = findViewById(R.id.button_my_explain);
        myInformationButton = findViewById(R.id.button_my_information);

        //点击“我的评论”跳转到我的评论
        myCommentsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyPageActivity.this, MyCommentsActivity.class);
                startActivity(intent);
            }
        });


        //点击“我的讲解”跳转到我的讲解
        myExplainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyPageActivity.this, MyExplainActivity.class);
                startActivity(intent);
            }
        });

        //点击“个人信息”跳转到个人信息界面
        myInformationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyPageActivity.this, MyInformationActivity.class);
                startActivity(intent);
            }
        });
    }
}