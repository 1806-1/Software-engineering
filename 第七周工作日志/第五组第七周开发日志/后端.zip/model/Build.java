package com.wenr.model;

public class Build {

	public int louhao;
	public int louceng;
	public int fangjian;
	public int alllouceng;
	public int remainfang;
	public String time;
	public String unkown;
	public int getLouhao() {
		return louhao;
	}
	public void setLouhao(int louhao) {
		this.louhao = louhao;
	}
	public int getLouceng() {
		return louceng;
	}
	public void setLouceng(int louceng) {
		this.louceng = louceng;
	}
	public int getFangjian() {
		return fangjian;
	}
	public void setFangjian(int fangjian) {
		this.fangjian = fangjian;
	}
	public int getAlllouceng() {
		return alllouceng;
	}
	public void setAlllouceng(int alllouceng) {
		this.alllouceng = alllouceng;
	}
	public int getRemainfang() {
		return remainfang;
	}
	public void setRemainfang(int remainfang) {
		this.remainfang = remainfang;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getUnkown() {
		return unkown;
	}
	public void setUnkown(String unkown) {
		this.unkown = unkown;
	}

}
