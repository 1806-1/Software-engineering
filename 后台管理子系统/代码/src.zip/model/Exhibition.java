package model;

import java.sql.Date;

public class Exhibition {
    private int  id;
    private String exhname;
    private Date time;
    private String introduction;
    private String photo;
    private String museumName;


    @Override
    public String toString() {
        return "Exhibition{" +
                "id=" + id +
                ", exhname='" + exhname + '\'' +
                ", time=" + time +
                ", introduction='" + introduction + '\'' +
                ", photo='" + photo + '\'' +
                ", museumName='" + museumName + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExhname() {
        return exhname;
    }

    public void setExhname(String exhname) {
        this.exhname = exhname;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getMuseumName() {
        return museumName;
    }

    public void setMuseumName(String museumName) {
        this.museumName = museumName;
    }
}
