package com.example.login1.ui.my_page;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toolbar;

import com.example.login1.R;
import com.example.login1.data.MyInformation;

import org.w3c.dom.Text;

public class MyInformationActivity extends AppCompatActivity {

    //声明控件
    private TextView tv_my_name;
    private TextView tv_my_id;
    private TextView tv_my_email;
    private TextView tv_my_phone;
    private androidx.appcompat.widget.Toolbar toolbar;

    //更新显示个人信息
    public void freshInformation(){
        tv_my_phone.setText(MyInformation.getPhone());
        tv_my_name.setText(MyInformation.getName());
        tv_my_id.setText(MyInformation.getId());
        tv_my_email.setText(MyInformation.getEmail());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_information);

        //找到控件
        tv_my_name = findViewById(R.id.myName);
        tv_my_id = findViewById(R.id.myId);
        tv_my_email = findViewById(R.id.myEmail);
        tv_my_phone = findViewById(R.id.myPhone);
        toolbar=findViewById(R.id.my_information_toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        //更新显示个人信息
        freshInformation();

    }
}