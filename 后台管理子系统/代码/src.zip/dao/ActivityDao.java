package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import model.Activity;
import util.DBUtil2;

public class ActivityDao {
//    public static void main(String[] args) {
//        ActivityDao activityDao = new ActivityDao();
//        Activity activity = new Activity();
//        activity.setActname("2222");
//        activity.setMuseumName("2222");
//        activity.setTime(java.sql.Date.valueOf("2020-08-10"));
//        activity.setIntroduction("2222");
//        activity.setPhoto("2222");
//        if (activityDao.addActivity(activity)) {
//            System.out.println("333333333333");
//        }
//
//    }

    public  void close(PreparedStatement pstmt, Connection conn) {

        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public  void close(ResultSet rs,PreparedStatement pstmt, Connection conn ) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
       close(pstmt,conn);
    }

    public ArrayList<Activity> getAllActivity() {

        ArrayList<Activity> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from activity";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getAct(rs));
            }
            close(rs,pstmt,conn);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            return list;
        }


    }

    public Activity getAct(ResultSet rs) throws SQLException {
        Activity activity = new Activity();
        activity.setId(rs.getInt("id"));
        activity.setActname(rs.getString("actname"));
        activity.setMuseumName(rs.getString("museumName"));
        activity.setTime(rs.getDate("time"));
        activity.setIntroduction(rs.getString("introduction"));
        activity.setPhoto(rs.getString("photo"));
        return activity;
    }

    public boolean addActivity(Activity activity) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "insert into activity(actname,museumName,time,introduction,photo) values(?,?,?,?,?)";
            pstmt = change(activity, conn, sql);
            pstmt.executeUpdate();
            close(pstmt,conn);
            WriterDao writerDao = new WriterDao();
            Date date = new Date();
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = simple.format(date.getTime());
            String replace = activity.toString().replace("\\", " ");
            replace = replace.replace("\n", " ");
            writerDao.write("\"操作\":\"增加\",\"操作时间\":\""+
                    format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
            return true;
        } catch (SQLException ex) {
            return false;
        }

    }

    public PreparedStatement change(Activity activity, Connection conn, String sql) throws SQLException {
        PreparedStatement pstmt;
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, activity.getActname());
        pstmt.setString(2, activity.getMuseumName());
        pstmt.setDate(3, activity.getTime());
        pstmt.setString(4, activity.getIntroduction());
        pstmt.setString(5, activity.getPhoto());
        return pstmt;
    }

    public boolean updateActivity(Activity activity) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "update `activity` set actname=?,museumName=?,time=?,introduction=?,photo=? where id=?";
            pstmt = change(activity, conn, sql);
            pstmt.setInt(6,activity.getId());
            pstmt.executeUpdate();
            close(pstmt,conn);
            WriterDao writerDao = new WriterDao();
            Date date = new Date();
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = simple.format(date.getTime());
            String replace = activity.toString().replace("\\", " ");
            replace = replace.replace("\n", " ");
            writerDao.write("\"操作\":\"修改\",\"操作时间\":\""+
                    format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
            return true;
        } catch (SQLException ex) {
            return false;
        }


    }

    public boolean deleteActivity(int id) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        Activity activity = getActivityById(id);
        WriterDao writerDao = new WriterDao();
        Date date = new Date();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simple.format(date.getTime());
        String replace = activity.toString().replace("\\", " ");
        replace = replace.replace("\n", " ");
        writerDao.write("\"操作\":\"删除\",\"操作时间\":\""+
                format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "delete from activity where id=? ";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            close(pstmt,conn);

            return true;
        } catch (SQLException ex) {
            return false;
        }

    }

    public Activity getActivityById(int id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Activity act=new Activity();
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from activity where id=? ";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
           if(rs != null && rs.next()) {
                act = getAct(rs);
           }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return act;
        }

    }

    public ArrayList<Activity> getActivityByTime(Date date) {

        ArrayList<Activity> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from activity where time >=?";
            pstmt = conn.prepareStatement(sql);
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
            pstmt.setString(1, simple.format(date));
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getAct(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public ArrayList<Activity> getActivityByTime(Date date1,Date date2) {

        ArrayList<Activity> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from activity where time between ? and ?";
            pstmt = conn.prepareStatement(sql);
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
            pstmt.setString(1, simple.format(date1));
            pstmt.setString(2, simple.format(date2));
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getAct(rs));

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public ArrayList<Activity> getActivityByMN(String name) {

        ArrayList<Activity> list = new ArrayList();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from activity where museumName=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getAct(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public ArrayList<Activity> getActivityByAN(String name) {

        ArrayList<Activity> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from activity where actname=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getAct(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public ArrayList<Activity> getActivityByTwo(String name,String name2) {

        ArrayList<Activity> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from activity where actname=? and museumName=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, name2);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getAct(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }
}
