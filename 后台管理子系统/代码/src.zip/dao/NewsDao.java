package dao;

import model.Activity;
import model.News;
import util.DBUtil2;
import dao.WriterDao;
import java.util.Date;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.List;

public class  NewsDao{
    public  void close(PreparedStatement pstmt, Connection conn) {

        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public  void close(ResultSet rs,PreparedStatement pstmt, Connection conn ) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        close(pstmt,conn);
    }

    public ArrayList<News> getNewsByMuseum(String museum) {
        ArrayList<News> list = new ArrayList();
        News news = new News();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from news where museum = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, museum);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getNews(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
           close(rs,pstmt,conn);
           return list;
        }

    }

    public News getNews(ResultSet rs) throws SQLException {
        News news = new News();
        news.setId(rs.getLong("id"));
        news.setMuseum(rs.getString("museum"));
        news.setTime(rs.getDate("time"));
        news.setType(rs.getString("type"));
        news.setContent(rs.getString("content"));
        news.setPhoto(rs.getString("photo"));
        news.setSource(rs.getString("source"));
        return news;
    }

    public ArrayList<News> getAllNews() {
        ArrayList<News> list = new ArrayList();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from news ";
            pstmt = conn.prepareStatement(sql);

            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {

                list.add(getNews(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }

    }


    public ArrayList<News> getNewsByTime(Date date) {
        ArrayList<News> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from news where time >= ?";
            pstmt = conn.prepareStatement(sql);
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
            pstmt.setString(1, simple.format(date));
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getNews(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }
    }
    
    public News getNewsById(int id) {
        News news = new News();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from news where id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,  id);
            rs = pstmt.executeQuery();
            if (rs != null && rs.next()) {
                news=getNews(rs);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return news;
        }
    }



    public boolean addNews(News news) {
    	 Connection conn = null;
         PreparedStatement pstmt = null;

         try {
             DBUtil2 dbUtil2 = new DBUtil2();
             conn = dbUtil2.getConnection();

                String sql = "insert into `news`(museum,time,type,content,photo,source) values(?,?,?,?,?,?)";
                pstmt = change(news, conn, sql);
                pstmt.executeUpdate();
                close(pstmt,conn);
                WriterDao writerDao = new WriterDao();
                Date date = new Date();
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
                String replace = news.toString().replace("\\", " ");
                replace = replace.replace("\n", " ");
                writerDao.write("\"操作\":\"增加\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
                return true;
            } catch (SQLException ex) {
                return false;
            }

        }

        public PreparedStatement change(News news, Connection conn, String sql) throws SQLException {
            PreparedStatement pstmt;
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, news.getMuseum());
            pstmt.setDate(2, news.getTime());
            pstmt.setString(3, news.getType());
            pstmt.setString(4, news.getContent());
            pstmt.setString(5, news.getPhoto());
            pstmt.setString(6, news.getSource());
            return pstmt;
        }


    public boolean deleteNewsByID(long id) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        News newsById = getNewsById(Math.toIntExact(id));
        WriterDao writerDao = new WriterDao();
        Date date = new Date();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simple.format(date.getTime());
        String replace = newsById.toString().replace("\\", " ");
        replace = replace.replace("\n", " ");
        writerDao.write("\"操作\":\"删除\",\"操作时间\":\""+
                format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "delete from `news` where id=? ";
            pstmt = conn.prepareStatement(sql);
            pstmt.setLong(1, id);
            pstmt.executeUpdate();
            close(pstmt,conn);
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }


    }


    public boolean updateNews(News news) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "update `news` set museum=?,time=?,type=?,content=?,photo=?,source=? where id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, news.getMuseum());
            pstmt.setDate(2, news.getTime());
            pstmt.setString(3, news.getType());
            pstmt.setString(4, news.getContent());
            pstmt.setString(5, news.getPhoto());
            pstmt.setString(6, news.getSource());
            pstmt.setLong(7, news.getId());
            pstmt.executeUpdate();
            close(pstmt,conn);
            WriterDao writerDao = new WriterDao();
            Date date = new Date();
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = simple.format(date.getTime());
            String replace = news.toString().replace("\\", " ");
            replace = replace.replace("\n", " ");
            writerDao.write("\"操作\":\"修改\",\"操作时间\":\""+
                    format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
            return  true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }


    }
}
