package com.example.login1.ui.my_page;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.login1.R;
import com.example.login1.data.CommentsAdapter;
import com.example.login1.data.MyComments;
import com.example.login1.data.MyInformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MyCommentsActivity extends AppCompatActivity {

    //声明控件
    private static final String BASEURL = "http://10.12.84.155/MyComment";
    private androidx.appcompat.widget.Toolbar toolbar;

    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_comments);

        toolbar = findViewById(R.id.toolbar_my_comments);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recycler_comments);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);


        //get方式userid参数请求评论
        String userid = MyInformation.getId();
        String url = BASEURL + "?userid=" + userid;

        //在子线程进行网络请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.i("try最上面的信息", "");

                    URL urls = new URL(url);
                    HttpURLConnection httpURLConnection = null;
                    BufferedReader bufferedReader = null;

                    httpURLConnection = (HttpURLConnection) urls.openConnection();
                    httpURLConnection.setRequestMethod("GET");  //设置请求方法为get
                    httpURLConnection.setConnectTimeout(5000);  //连接超时
                    httpURLConnection.setReadTimeout(5000);

                    InputStream in = httpURLConnection.getInputStream();
                    bufferedReader = new BufferedReader(new InputStreamReader(in));

                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        result.append(line);
                    }

                    String returnComments = result.toString();
                    Log.i("返回的评论json", returnComments);

                    List<MyComments.CommentsDTO> theComment = new ArrayList<>();
                    commentJsonParse(returnComments, theComment);

                    Log.i("list-theComment", theComment.get(1).getContent());  //这次传进来了。static不能随便用

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //传list进去
                            CommentsAdapter commentsAdapter = new CommentsAdapter(theComment);

//                            LinearLayoutManager layoutManager = new LinearLayoutManager(this);
                            recyclerView.setLayoutManager(layoutManager);
                            //设置adapter
                            recyclerView.setAdapter(commentsAdapter);
                        }
                    });

                    for (int i = 0; i < theComment.size(); i++) {
                        MyComments.CommentsDTO singleCommentsDTO = (MyComments.CommentsDTO) theComment.get(i);
//            commentsDTOList.add(singleCommentsDTO);
                        Log.v("for显示评论信息", singleCommentsDTO.getContent());
                    }

                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }
            }

        }).start();
    }//onCreate末尾


    //解析封装评论json
    private void commentJsonParse(String returnComments, List<MyComments.CommentsDTO> theComment) throws JSONException {
        //封装java对象
        MyComments comment = new MyComments();

        JSONObject jsonObject = new JSONObject(returnComments);

        //第一层解析
        int number = jsonObject.optInt("number");
        //comments：json数组[{},{},{}]
        JSONArray comments = jsonObject.optJSONArray("comments");

        //第一层封装
        comment.setNumber(number);
        //theComment：list集合
//        theComment = new ArrayList<>();
        comment.setComments(theComment);

        //第二层解析
        for (int i = 0; i < number; i++) {
            assert comments != null;
            JSONObject jsonObject1 = comments.optJSONObject(i);
            if (jsonObject1 != null) {
                String museum = jsonObject1.optString("museum");
                String content = jsonObject1.optString("content");
                String date = jsonObject1.optString("date");
                //第二层封装

                //commentsDTO：评论静态类的对象
                MyComments.CommentsDTO commentsDTO = new MyComments.CommentsDTO();
                commentsDTO.setMuseum(museum);
                commentsDTO.setDate(date);
                commentsDTO.setContent(content);
                theComment.add(commentsDTO);

                Log.i("第" + i + "个评论", theComment.get(i).toString());    //空的？打印出来是地址
//                Log.i("评论内容", commentsDTO.getContent());
//                Log.i("评论时间", commentsDTO.getDate());
//                Log.i("博物馆", commentsDTO.getMuseum());
            }
        }
//        Log.i("寻找解析后的评论json",theComment.toString());
//        return comments;
//        错：return theComment;
    }
}