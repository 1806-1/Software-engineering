package com.example.login1.data;

public class MyInformation {

    private static String success;
    private static String id;
    private static String phone;
    private static String name;
    private static String email;

    public MyInformation(String success, String id, String phone, String name, String email) {
        this.success = success;
        this.id = id;
        this.phone = phone;
        this.name = name;
        this.email = email;
    }

    public MyInformation() {
    }

    public static String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public static String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public static String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public static String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "MyInformation{" +
                "success='" + success + '\'' +
                ", id='" + id + '\'' +
                ", phone='" + phone + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                '}';
    }

}
