package model;

/**
 * @author zebra 1024
 * @create 2021-04-30 16:16
 */
public class Overview {
    private long id;
    private String bwgname;
    private String introduction;
    private String photo;



    private String address;
    private long exhibition_num;
    private long collection_num;
    private long comment_num;
    private String jingwei;

    public String getJingwei() {
        return jingwei;
    }

    public void setJingwei(String jingwei) {
        this.jingwei = jingwei;
    }

    public long getExhibition_num() {
        return exhibition_num;
    }

    public void setExhibition_num(long exhibition_num) {
        this.exhibition_num = exhibition_num;
    }

    public long getCollection_num() {
        return collection_num;
    }

    public void setCollection_num(long collection_num) {
        this.collection_num = collection_num;
    }

    public long getComment_num() {
        return comment_num;
    }

    public void setComment_num(long comment_num) {
        this.comment_num = comment_num;
    }



    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBwgname() {
        return bwgname;
    }

    public void setBwgname(String bwgname) {
        this.bwgname = bwgname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    @Override
    public String toString() {
        return "Overview{" +
                "id=" + id +
                ", bwgname='" + bwgname + '\'' +
                ", introduction='" + introduction + '\'' +
                ", photo='" + photo + '\'' +
                ", address='" + address + '\'' +
                ", exhibition_num=" + exhibition_num +
                ", collection_num=" + collection_num +
                ", comment_num=" + comment_num +
                '}';
    }
}
