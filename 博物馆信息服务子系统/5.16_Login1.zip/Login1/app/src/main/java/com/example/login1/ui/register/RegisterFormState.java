package com.example.login1.ui.register;

import android.content.Intent;

import androidx.annotation.Nullable;

class RegisterFormState {
}
