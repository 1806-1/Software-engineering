package com.example.login1.ui.login;

import android.app.Activity;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.login1.R;
import com.example.login1.data.MyInformation;
import com.example.login1.ui.forget_password.ForgetPasswordActivity;
import com.example.login1.ui.my_page.MyPageActivity;
import com.example.login1.ui.register.RegisterActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {

    //访问地址
    private static final String BASEURL = "http://10.12.84.155/Login";

    //声明控件
    private LoginViewModel loginViewModel;
    Button registerButton;  //“去注册”按钮
    Button forgetPasswordButton;    //忘记密码按钮
//    final String loginSuccess = "true";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginViewModel = new ViewModelProvider(this, new LoginViewModelFactory()).get(LoginViewModel.class);

        //找到控件
        final EditText usernameEditText = findViewById(R.id.number);    //用户名
        final EditText passwordEditText = findViewById(R.id.password);
        final Button loginButton = findViewById(R.id.login);
        final ProgressBar loadingProgressBar = findViewById(R.id.loading);
        registerButton = findViewById(R.id.register_now);
        forgetPasswordButton = findViewById(R.id.forget_password);

//        MyInformation myInformation;

        //背景透明度
        View v = findViewById(R.id.loginActivity);
        v.getBackground().setAlpha(110);

        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }

                loginButton.setEnabled(loginFormState.isDataValid());

                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });

        //获取登录结果(未使用)
        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
                loadingProgressBar.setVisibility(View.GONE);

                //登录失败
                if (loginResult.getError() != null) {
                    showLoginFailed(loginResult.getError());
                }

                //登录成功
                if (loginResult.getSuccess() != null) {
                    updateUiWithUser(loginResult.getSuccess());
                }
                setResult(Activity.RESULT_OK);
                //Complete and destroy login activity once successful
                //成功后结束并销毁登录activity
                finish();
            }
        });

        //账号密码edittext格式动态监控
        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loginViewModel.login(usernameEditText.getText().toString(),
                            passwordEditText.getText().toString());
                }
                return false;
            }
        });


        //登录按钮点击事件
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);
//                loginViewModel.login(usernameEditText.getText().toString(),
//                        passwordEditText.getText().toString());

                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                String url = BASEURL + "?username=" + username + "&password=" + password;   //get方法登录的规则，用户名和密码加在url后

                //在子线程进行网络请求
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {      //登录实现
                            URL urls = new URL(url);
                            HttpURLConnection httpURLConnection = null;
                            BufferedReader bufferedReader = null;

                            httpURLConnection = (HttpURLConnection) urls.openConnection();
                            httpURLConnection.setRequestMethod("GET");  //设置请求方法为get
                            httpURLConnection.setConnectTimeout(10000);  //连接超时：5000毫秒
                            httpURLConnection.setReadTimeout(10000);

                            InputStream in = httpURLConnection.getInputStream();
                            bufferedReader = new BufferedReader(new InputStreamReader(in));

                            StringBuilder result = new StringBuilder();
                            String line;
                            while ((line = bufferedReader.readLine()) != null) {
                                result.append(line);
                            }

//                            {
//                                "phone":"1881",
//                                "success":true,
//                                  "root":true,
//                                "name":"root",
//                                "id":"4",
//                                "email":"root@qq.com",
//                                  "status":1
//                            }

                            String returnJson = result.toString();
                            loginJsonParse(returnJson); //解析登录后获取的json数据
                            Log.i("子线程-登录返回信息", returnJson);

                            if (loginJsonParse(returnJson).equals("true")) {  //判断返回的success值
//                            if (returnJson.equals(loginSuccess)) {  //登录成功，进行跳转界面至“我的”等操作

                                Intent intent = new Intent(LoginActivity.this, MyPageActivity.class);
                                startActivity(intent);

                                Looper.prepare();
                                Toast.makeText(LoginActivity.this, "登录成功，欢迎您", Toast.LENGTH_SHORT).show();
                                Looper.loop();

                                loadingProgressBar.setVisibility(View.INVISIBLE);


                            } else {    //登录失败
                                loadingProgressBar.setVisibility(View.INVISIBLE);
                                Looper.prepare();
                                Toast.makeText(LoginActivity.this, "登录失败", Toast.LENGTH_SHORT).show();
                                Looper.loop();
                            }

                        } catch (IOException | JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();

            }

            //解析登录后获取的json数据
            private String loginJsonParse(String json) throws JSONException {

                MyInformation information = null;

                JSONObject jsonObject = new JSONObject(json);
//                    JSONObject jsonObject = new JSONObject(model.getData());

                String success = jsonObject.optString("success");
//                    boolean success=jsonObject.optBoolean("success");
                String id = jsonObject.optString("id");
                String phone = jsonObject.optString("phone");
                String email = jsonObject.optString("email");
                String name = jsonObject.optString("email");
                Log.i("loginJsonParse方法内-登录状态", success);

                information = new MyInformation(success, id, phone, email, name);
                information.setEmail(email);
                information.setId(id);
                information.setName(name);
                information.setPhone(phone);
                information.setSuccess(success);

                Log.i("验证myinformation实体类", information.getEmail());

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                            Toast.makeText(LoginActivity.this, "登录成功，欢迎您，"+id, Toast.LENGTH_SHORT).show();
                    }
                });

                return success;
            }
        });

        //点击去注册按钮跳转到注册界面
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        //点击忘记密码按钮跳转到重置密码界面
        forgetPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, ForgetPasswordActivity.class);
                startActivity(intent);
            }
        });
    }

    private void updateUiWithUser(LoggedInUserView model) {
        String welcome = getString(R.string.welcome) + model.getDisplayName();
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }
}