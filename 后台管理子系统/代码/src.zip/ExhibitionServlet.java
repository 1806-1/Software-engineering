
import dao.ExhibitionDao;
import dao.NewsDao;
import dao.WriterDao;
import dao.dataDao;
import model.Exhibition;
import model.News;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;




public class ExhibitionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

           if (method.equals("delete")){
               int id= Integer.parseInt(request.getParameter("id"));
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               if (exhibitionDao.deleteExhibition(id)) {
                   out.print("yes");
               } else
                   out.print("no");
           }
           else if (method.equals("update")){
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (exhibitionDao.updateExhibition(create(request))) {
                   out.println("yes");
               } else
                   out.println("no");
        	   
            }
           else if ("look".equals(method)){
               ArrayList<Exhibition> list = new ArrayList();
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               list=exhibitionDao.getExhibitionByMN(request.getParameter("museum"));
               getOne(out,list);
            }
           else if ("add".equals(method)) {
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
              if (exhibitionDao.addExhibition(create2(request))) {
                  out.println("yes");
              } else
                   out.println("no");
               System.out.println(request.getParameter("nn"));

           }
           else if ("lookkkk".equals(method)){
               ArrayList<Exhibition> list = new ArrayList();
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               list=exhibitionDao.getExhibitionByMN("中国国家博物馆");
               getOne(out,list);
            }
           else if ("lookkkk1".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Exhibition> list = new ArrayList();
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               list=exhibitionDao.getExhibitionByMN("北京故宫博物院");
               getOne(out,list);
            }
           else if ("lookkkk2".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Exhibition> list = new ArrayList();
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               list=exhibitionDao.getExhibitionByMN("中国科学技术馆");
               getOne(out,list);
            }
           else if ("lookkkk3".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Exhibition> list = new ArrayList();
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               list=exhibitionDao.getExhibitionByMN("首都博物馆");
               getOne(out,list);
            }
           else if ("lookkkk4".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Exhibition> list = new ArrayList();
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               list=exhibitionDao.getExhibitionByMN("北京鲁迅博物馆");
               getOne(out,list);
            }
           else if ("lookkkk5".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Exhibition> list = new ArrayList();
               ExhibitionDao exhibitionDao = new ExhibitionDao();
               list=exhibitionDao.getExhibitionByMN("无锡博物院");
               getOne(out,list);
            }
          
           else if ("restore".equals(method)) {
        	   dataDao dataDao = new dataDao();
        	   String data = request.getParameter("date");
        	   String table = request.getParameter("from");
        	   String rootname = request.getParameter("rootname");
        	   Date date =  new Date(System.currentTimeMillis());
               SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               String format = simple.format(date.getTime());
        	   WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               writerDao.write("\"操作\":\"恢复\",\"操作时间\":\""+
                       format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
        	   if (dataDao.recover(data,table)) {
                   out.println("yes");
               } else
                   out.println("no");
              

           }
           else if ("backup".equals(method)) {
        	   dataDao dataDao = new dataDao();
        	   String data = request.getParameter("date");
        	   String table = request.getParameter("from");
        	   String rootname = request.getParameter("rootname");
        	   Date date =  new Date(System.currentTimeMillis());
               SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               String format = simple.format(date.getTime());
        	   WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               writerDao.write("\"操作\":\"备份\",\"操作时间\":\""+
                       format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
               if (dataDao.backup(data,table)) {
                   out.println("yes");
               } else
                   out.println("no");
              

           }
          

        }
        else{
            getALL(out);
        }
    }
    public void getALL(PrintWriter out){
        ExhibitionDao exhibitionDao = new ExhibitionDao();
        ArrayList<Exhibition> list = exhibitionDao.getAllExhibition();
        getOne(out,list);
    }

    public void getOne(PrintWriter out,ArrayList<Exhibition> list){

        int size = list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");


        for (int i = 0; i < size; i++) {
            buffer.append("{\"id\":"+list.get(i).getId()+",");

            String exhname = list.get(i).getExhname().replace("\"", " ").trim();
            exhname=exhname.replace("\\", " ").trim();
            exhname=exhname.replace("\n", " ").trim();
            buffer.append("\"exhname\": \""+exhname+"\",");


            buffer.append("\"time\":\""+simple.format(list.get(i).getTime())+"\",");

            String introduction = list.get(i).getIntroduction();
            introduction=introduction.replace("\n","");
            introduction=introduction.replace("\""," ").trim();
            introduction=introduction.replace("\\"," ").trim();
            buffer.append("\"introduction\":\""+introduction+"\",");

            buffer.append("\"photo\":\""+list.get(i).getPhoto()+"\",");
           
            String museumName = list.get(i).getMuseumName().replace("\"", " ").trim();
            museumName=museumName.replace("\\", " ").trim();
            museumName=museumName.replace("\n", " ").trim();
            buffer.append("\"museumName\":\""+museumName+"\"}");
            if (i!=size-1)
                buffer.append(",");
        }
        buffer.append("]}");
        String s1 = new String(buffer);
        out.print(s1);
    }

    public Exhibition create(HttpServletRequest request) {
        Exhibition exhibition = new Exhibition();
        exhibition.setId(Integer.parseInt(request.getParameter("id")));
        exhibition.setExhname(request.getParameter("exhname"));
        exhibition.setTime(Date.valueOf(request.getParameter("time")));
        exhibition.setIntroduction(request.getParameter("introduction"));
        exhibition.setPhoto(request.getParameter("photo"));
        exhibition.setMuseumName(request.getParameter("museumName"));
        return exhibition;
    }
    public Exhibition create2(HttpServletRequest request) {
        Exhibition exhibition = new Exhibition();
        exhibition.setExhname(request.getParameter("exhname"));
        exhibition.setTime(Date.valueOf(request.getParameter("time")));
        exhibition.setIntroduction(request.getParameter("introduction"));
        exhibition.setPhoto(request.getParameter("photo"));
        exhibition.setMuseumName(request.getParameter("museumName"));
        return exhibition;
    }






}
