package dao;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class dataDao {

    public Boolean backup(String data,String from){
        Runtime runtime = Runtime.getRuntime();

        String b="cmd /c D:/Javaweb-database/mysql-8.0.23-winx64/bin/mysqldump -h182.92.221.222 -P3306 -uroot -pCS1806se. "+data+" "+from+">D:/"+from+".sql";

        try {
            runtime.exec(b);


            

          
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }


    }
    public Boolean recover(String data,String from){
        Runtime runtime=Runtime.getRuntime();

        String a="cmd /c D:/Javaweb-database/mysql-8.0.23-winx64/bin/mysql -h182.92.221.222 -P3306 -uroot -pCS1806se. "+data+"< d:\\"+from+".sql";

        try {
            runtime.exec(a);

           return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }


    }



}
