package com.example.login1.ui.register;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.example.login1.R;
import com.example.login1.ui.login.LoginViewModel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class RegisterActivity extends AppCompatActivity {

    //访问地址
    private static final String BASEURL = "http://localhost:8080";

    //声明部分控件
    Button agreement;   //查看协议按钮
    CheckBox checkBoxAgreement;   //勾选同意复选框

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //声明/找到控件
        final EditText numberRegEditText = findViewById(R.id.numberRegister);
        final EditText passwordRegEditText = findViewById(R.id.passwordRegister);
        Button registerBtn = findViewById(R.id.registering);
        agreement = findViewById(R.id.userAgreement);
        checkBoxAgreement = findViewById(R.id.checkAgreement);

        //查看用户协议按钮（暂时无效）
        agreement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialogAgreement = new AlertDialog.Builder(RegisterActivity.this);
                dialogAgreement.setTitle("用户协议");
                dialogAgreement.setMessage("一、特别提示\n在此特别提醒您（用户）在注册成为***用户之前，请认真阅读本《***用户服务协议》……");
            }
        });


        //注册按钮点击事件
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = numberRegEditText.getText().toString();   //用户名username
                String password = passwordRegEditText.getText().toString(); //密码password

                if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {   //如果输入为空
                    Toast.makeText(getApplicationContext(), "必须输入号码和密码", Toast.LENGTH_SHORT).show();
                }
                else {
                    //进行注册（存储账号，跳转页面等）

                }
            }
        });

        //勾选同意后激活注册按钮
        checkBoxAgreement.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (checkBoxAgreement.isChecked()) {
                    registerBtn.setEnabled(true);
                } else {
                    registerBtn.setEnabled(false);
                }
            }
        });
    }
}