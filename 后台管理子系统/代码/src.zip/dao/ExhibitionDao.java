package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import model.Exhibition;
import util.DBUtil2;

public class ExhibitionDao {
//    public static void main(String[] args) {
//        ExhibitionDao exhibitionDao = new ExhibitionDao();
//        String s = new String("中国国家博物馆");
//        System.out.println(s);
//        ArrayList<Exhibition> exhibitionByMN = exhibitionDao.getExhibitionByMN(s);
//        System.out.println(exhibitionByMN.size());
//
//    }


    public  void close(PreparedStatement pstmt, Connection conn) {

        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public  void close(ResultSet rs,PreparedStatement pstmt, Connection conn ) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        close(pstmt,conn);
    }

    public ArrayList<Exhibition> getAllExhibition() {

        ArrayList<Exhibition> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from exhibition";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getExh(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public Exhibition getExhibitionById(int id) {

        Exhibition exhibition = new Exhibition();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from exhibition";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            if (rs != null && rs.next()) {
                exhibition=getExh(rs);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return exhibition;
        }


    }

    public Exhibition getExh(ResultSet rs) throws SQLException {
        Exhibition exhibition = new Exhibition();
        exhibition.setId(rs.getInt(1));
        exhibition.setExhname(rs.getString(2));
        exhibition.setTime(rs.getDate(3));
        exhibition.setIntroduction(rs.getString(4));
        exhibition.setPhoto(rs.getString(5));
        exhibition.setMuseumName(rs.getString(6));
        return exhibition;
    }

    public boolean addExhibition(Exhibition exhibition) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();


                String sql = "insert into exhibition(exhname,time,introduction,photo,museumName) values(?,?,?,?,?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, exhibition.getExhname());
                pstmt.setDate(2, exhibition.getTime());
                pstmt.setString(3, exhibition.getIntroduction());
                pstmt.setString(4, exhibition.getPhoto());
                pstmt.setString(5, exhibition.getMuseumName());
                pstmt.executeUpdate();
                close(pstmt,conn);
            WriterDao writerDao = new WriterDao();
            Date date = new Date();
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = simple.format(date.getTime());
            String replace = exhibition.toString().replace("\\", " ");
            replace = replace.replace("\n", " ");
            writerDao.write("\"操作\":\"增加\",\"操作时间\":\""+
                    format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
                return true;



        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }


    }

    public boolean updateExhibition(Exhibition exhibition) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "update exhibition set exhname=?,museumName=?,time=?,introduction=?,photo=? where id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, exhibition.getExhname());
            pstmt.setString(2, exhibition.getMuseumName());
            pstmt.setDate(3, exhibition.getTime());
            pstmt.setString(4, exhibition.getIntroduction());
            pstmt.setString(5, exhibition.getPhoto());
            pstmt.setInt(6,exhibition.getId());
            pstmt.executeUpdate();
            close(pstmt,conn);
            WriterDao writerDao = new WriterDao();
            Date date = new Date();
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = simple.format(date.getTime());
            String replace = exhibition.toString().replace("\\", " ");
            replace = replace.replace("\n", " ");
            writerDao.write("\"操作\":\"修改\",\"操作时间\":\""+
                    format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            return false;
        }

    }

    public boolean deleteExhibition(int id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        Exhibition exhibitionById = getExhibitionById(id);
        WriterDao writerDao = new WriterDao();
        Date date = new Date();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simple.format(date.getTime());
        String replace = exhibitionById.toString().replace("\\", " ");
        replace = replace.replace("\n", " ");
        writerDao.write("\"操作\":\"删除\",\"操作时间\":\""+
                format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "delete from exhibition where id=? ";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            close(pstmt,conn);
            return  true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }

    }

    public int getId(String aa,String bb) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select id from exhibition where exhname=? and museumName=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, aa);
            pstmt.setString(2, bb);
            rs = pstmt.executeQuery();
            rs.next();
            int anInt = rs.getInt(1);
            close(rs,pstmt,conn);
            return anInt;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return -1;
        }

    }

    public ArrayList<Exhibition> getExhibitionByTime(Date date) {

        ArrayList<Exhibition> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from exhibition where time >=?";
            pstmt = conn.prepareStatement(sql);
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
            pstmt.setString(1, simple.format(date));
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getExh(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public ArrayList<Exhibition> getExhibitionByTime(Date date1,Date date2) {

        ArrayList<Exhibition> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from exhibition where time between ? and ?";
            pstmt = conn.prepareStatement(sql);
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
            pstmt.setString(1, simple.format(date1));
            pstmt.setString(2, simple.format(date2));
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getExh(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public ArrayList<Exhibition> getExhibitionByMN(String name) {

        ArrayList<Exhibition> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        System.out.println(name);
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from `exhibition` where museumName=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();

            while (rs != null && rs.next()) {
                list.add(getExh(rs));
            }


        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public ArrayList<Exhibition> getExhibitionByEN(String name) {

        ArrayList<Exhibition> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from exhibition where exhname=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getExh(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }
}
