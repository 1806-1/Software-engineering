package com.wenr.model;

import java.util.Date;

public class Comment {
	private int id;	  
	private int userID;
	private int museumID;
	private int score0;
	private int score1; 
	private int score2;
	private String discuss;
	private Date time;
	private int status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getMuseumID() {
		return museumID;
	}
	public void setMuseumID(int museumID) {
		this.museumID = museumID;
	}
	public int getScore0() {
		return score0;
	}
	public void setScore0(int score0) {
		this.score0 = score0;
	}
	public int getScore1() {
		return score1;
	}
	public void setScore1(int score1) {
		this.score1 = score1;
	}
	public int getScore2() {
		return score2;
	}
	public void setScore2(int score2) {
		this.score2 = score2;
	}
	public String getDiscuss() {
		return discuss;
	}
	public void setDiscuss(String discuss) {
		this.discuss = discuss;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
}
