package com.wenr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wenr.dao.TeacherDao;
import com.wenr.model.Student;
import com.wenr.model.Teacher;

public class TeacherServlet extends HttpServlet {

	public TeacherServlet() {
		super();
	}

	public void destroy() {
		super.destroy();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");

		String action = request.getParameter("action");
		String path = request.getContextPath();
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();

		if ("lookup".equals(action)) {
			int teacher1 = 0;
			int teacher2 = 0;
			if (request.getParameter("qinshi") != null
					&& request.getParameter("louhao") != null) {
				teacher1 = Integer.parseInt(request.getParameter("qinshi"));
				teacher2 = Integer.parseInt(request.getParameter("louhao"));

				ArrayList<Teacher> list = new ArrayList<>();
				TeacherDao dao = new TeacherDao();

				list = dao.getTeacherby(teacher1, teacher2);
				if (list != null) {
					request.setAttribute("teacherList", list);
					request.getRequestDispatcher("../SearchTeacher.jsp")
							.forward(request, response);
				} else
					out.println("<h1>��ѯʧ�ܣ������Ӧ�����Ҳ�����</h1>");
				out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/teacherSearch.jsp\">����</a>");

			}
		} else if ("queren".equals(action)) {
			int teacher1 = 0;
			int teacher2 = 0;
			if (request.getParameter("qinshi") != null
					&& request.getParameter("louhao") != null) {
				teacher1 = Integer.parseInt(request.getParameter("qinshi"));
				teacher2 = Integer.parseInt(request.getParameter("louhao"));
				TeacherDao dao = new TeacherDao();
				dao.queren(teacher1, teacher2);
				response.sendRedirect("../teacherSearch.jsp");
			}
		} else if ("delete".equals(action)) {
			TeacherDao TeacherDao = new TeacherDao();
			if (TeacherDao.deleteTeacher(
					Integer.parseInt(request.getParameter("qinshi")),
					Integer.parseInt(request.getParameter("louhao"))))
				out.println("<h1>ɾ���ɹ���</h1>");
			else
				out.println("<h1>ɾ��ʧ��!��鿴�����������Ƿ�����ѧ����ס</h1>");
			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/teacherSearch.jsp\">����</a>");

		} else if ("re".equals(action)) {

			TeacherDao dao = new TeacherDao();
			dao.re();
			response.sendRedirect("../teacherSearch.jsp");
		}
		else if ("lookup2".equals(action)) {
			int teacher1 = 0;
			int teacher2 = 0;
			if (request.getParameter("qinshi") != null
					&& request.getParameter("louhao") != null) {
				teacher1 = Integer.parseInt(request.getParameter("qinshi"));
				teacher2 = Integer.parseInt(request.getParameter("louhao"));

				ArrayList<Student> list = new ArrayList<>();
				TeacherDao dao = new TeacherDao();

				list = dao.getTeacherby2(teacher1, teacher2);
				if (list != null) {
					request.setAttribute("teacherList", list);
					request.getRequestDispatcher("../SearchTeacher2.jsp")
							.forward(request, response);
				} else
					out.println("<h1>��ѯʧ�ܣ������Ӧ�����Ҳ�����</h1>");
				out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/teacherSearch1.jsp\">����</a>");

			}
		} 

	}

}
