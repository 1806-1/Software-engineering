package com.zebra.entity;


import java.util.Date;

public class User {

  private long id;
  private String email;
  private String phone;
  private String name;
  private String password;
  private long status;
  private Date regtime;
  private long root;


  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }


  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }


  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }


  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }


  public long getStatus() {
    return status;
  }

  public void setStatus(long status) {
    this.status = status;
  }


  public Date getRegtime() {
    return regtime;
  }

  public void setRegtime(java.sql.Date regtime) {
    this.regtime = regtime;
  }


  public long getRoot() {
    return root;
  }

  public void setRoot(long root) {
    this.root = root;
  }


  @Override
  public String toString() {
    return "User{" +
            "id=" + id +
            ", email='" + email + '\'' +
            ", phone='" + phone + '\'' +
            ", name='" + name + '\'' +
            ", password='" + password + '\'' +
            ", status=" + status +
            ", regtime=" + regtime +
            ", root=" + root +
            '}';
  }
}
