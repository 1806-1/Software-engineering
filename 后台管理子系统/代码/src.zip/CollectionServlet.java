
import dao.CollectionDao;
import model.Collection;
import dao.WriterDao;
import dao.dataDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;




public class CollectionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

           if (method.equals("delete")){
               int id= Integer.parseInt(request.getParameter("id"));
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               CollectionDao collectionDao = new CollectionDao();
               if (collectionDao.deleteCollection(id)) {
                   out.print("yes");
               } else
                   out.print("no");
           }
           else if (method.equals("update")){
               CollectionDao collectionDao = new CollectionDao();
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (collectionDao.updateCollection(create(request))) {
                   out.println("yes");
               } else
                   out.println("no");
        	   
            }
           else if ("look".equals(method)){
               ArrayList<Collection> list = new ArrayList();
               CollectionDao collectionDao = new CollectionDao();
               list=collectionDao.getCollectionByMn(request.getParameter("museum"));
               getOne(out,list);
            }
           else if ("add".equals(method)) {
              CollectionDao collectionDao = new CollectionDao();
              String rootname = request.getParameter("rootname");
              WriterDao writerDao = new WriterDao();
              writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (collectionDao.addCollection(create2(request))) {
                   out.println("yes");
               } else
                   out.println("no");
              

           }
           else if ("lookkkk7".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Collection> list = new ArrayList();
               CollectionDao collectionDao = new CollectionDao();
               list=collectionDao.isClassic();
               getOne(out,list);
            }
           else if ("lookkkk8".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Collection> list = new ArrayList();
               CollectionDao collectionDao = new CollectionDao();
               list=collectionDao.isClassic1();
               getOne(out,list);
            }
           else if ("lookkkk9".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Collection> list = new ArrayList();
               CollectionDao collectionDao = new CollectionDao();
               list=collectionDao.isClassic3();
               getOne(out,list);
            }
           else if ("lookkkk10".equals(method)){
        	 
               ArrayList<Collection> list = new ArrayList();
               CollectionDao collectionDao = new CollectionDao();
               list=collectionDao.isClassic4();
               getOne(out,list);
            }
           else if ("restore".equals(method)) {
        	   dataDao dataDao = new dataDao();
        	   String data = request.getParameter("date");
        	   String table = request.getParameter("from");
        	   String rootname = request.getParameter("rootname");
        	   Date date =  new Date(System.currentTimeMillis());
               SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               String format = simple.format(date.getTime());
        	   WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               writerDao.write("\"操作\":\"恢复\",\"操作时间\":\""+
                       format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
        	   if (dataDao.recover(data,table)) {
                   out.println("yes");
               } else
                   out.println("no");
              

           }
           else if ("backup".equals(method)) {
        	   dataDao dataDao = new dataDao();
        	   String data = request.getParameter("date");
        	   String table = request.getParameter("from");
        	   String rootname = request.getParameter("rootname");
        	   Date date =  new Date(System.currentTimeMillis());
               SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               String format = simple.format(date.getTime());
        	   WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               writerDao.write("\"操作\":\"备份\",\"操作时间\":\""+
                       format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
               if (dataDao.backup(data,table)) {
                   out.println("yes");
               } else
                   out.println("no");
              

           }


        }
        else{
            getALL(out);
        }
    }
    public void getALL(PrintWriter out){
        CollectionDao collectionDao = new CollectionDao();
        ArrayList<Collection> list = collectionDao.getAllCollection();
        getOne(out,list);
    }

    public void getOne(PrintWriter out,ArrayList<Collection> list){

        int size = list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");


        for (int i = 0; i < size; i++) {
            buffer.append("{\"id\":"+list.get(i).getId()+",");

            String museumName = list.get(i).getMuseumName().replace("\""," ").trim();
            buffer.append("\"museumName\": \""+museumName+"\",");

            String type = list.get(i).getType().replace("\"", " ").trim();
            buffer.append("\"type\":\""+type+"\",");

            String colname = list.get(i).getColname().replace("\""," ").trim();
            buffer.append("\"colname\": \""+colname+"\",");

            String introduction = list.get(i).getIntroduction();
            introduction=introduction.replace("\n","");
            introduction=introduction.replace("\""," ").trim();
            buffer.append("\"introduction\":\""+introduction+"\",");
            
            buffer.append("\"status\":\""+list.get(i).getStatus()+"\",");
            buffer.append("\"photo\":\""+list.get(i).getPhoto()+"\"}");
            if (i!=size-1)
                buffer.append(",");
        }
        buffer.append("]}");
        String s1 = new String(buffer);
        out.print(s1);
    }

    public Collection create(HttpServletRequest request) {
        Collection collection = new Collection();
        collection.setId(Integer.parseInt(request.getParameter("id")));
        collection.setMuseumName(request.getParameter("museumName"));
        collection.setType(request.getParameter("type"));
        collection.setColname(request.getParameter("colname"));
        collection.setIntroduction(request.getParameter("introduction"));
        collection.setPhoto(request.getParameter("photo"));
        collection.setStatus(Integer.parseInt(request.getParameter("status")));
        return collection;
    }

    public Collection create2(HttpServletRequest request) {
        Collection collection = new Collection();
        collection.setId(Integer.parseInt(request.getParameter("id")));
        collection.setMuseumName(request.getParameter("museumName"));
        collection.setType(request.getParameter("type"));
        collection.setColname(request.getParameter("colname"));
        collection.setIntroduction(request.getParameter("introduction"));
        collection.setPhoto(request.getParameter("photo"));
        collection.setStatus(Integer.parseInt(request.getParameter("status")));
        return collection;
    }






}
