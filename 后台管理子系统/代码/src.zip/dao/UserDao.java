package dao;

import model.Collection;
import model.User;
import util.DBUtil2;
import java.sql.*;
import java.util.ArrayList;

import java.text.SimpleDateFormat;
import java.util.Date;

public class  UserDao{

    public  void close(PreparedStatement pstmt, Connection conn) {

        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public  void close(ResultSet rs,PreparedStatement pstmt, Connection conn ) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        close(pstmt,conn);
    }

    public User getUserById(int id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        User user = new User();
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("USER");
            String sql = "select * from user where id = ?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            if (rs != null && rs.next()) {
                user=getUser(rs);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }finally {
            close(rs,pstmt,conn);
            return user;
        }

    }

    public String getUserPass(String name) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String string=new String();
        User user = new User();
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("USER");
            String sql = "select password from user where name = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            if (rs != null && rs.next()) {
                string= rs.getString(1);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }finally {
            close(rs,pstmt,conn);
            return string;
        }

    }

    public Boolean setUserPass(String name,String password) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String string=new String();
        User user = new User();
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("USER");
            String sql = "update `user` set password=? where name=?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, password);
            pstmt.setString(2, name);
            pstmt.executeUpdate();
            close(pstmt,conn);
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }

    }

    public User getUserByName(String name) {
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            User user = new User();

        try {
                DBUtil2 dbUtil2 = new DBUtil2();
			    conn = dbUtil2.getConnection("USER");
                String sql = "select * from user where name = ?";

                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, name);
                rs = pstmt.executeQuery();
                if (rs != null && rs.next()) {
                    user=getUser(rs);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }finally {
            close(rs,pstmt,conn);
            return user;
        }

        }

    public User getUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setId(rs.getLong("id"));
        user.setEmail(rs.getString("email"));
        user.setPhone(rs.getString("phone"));
        user.setName(rs.getString("name"));
        user.setPassword(rs.getString("password"));
        user.setStatus(rs.getLong("status"));
        user.setRegtime(rs.getDate("regtime"));
        user.setRoot(rs.getLong("root"));
        return user;
    }

    public ArrayList<User> getAllUser() {
        ArrayList<User> list = new ArrayList();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("USER");
            String sql = "select * from user ";

            pstmt = conn.prepareStatement(sql);

            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {


                list.add(getUser(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }finally {
            close(rs,pstmt,conn);
            return list;
        }

    }

    public boolean addUser(User user) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");

                String sql = "insert into `user`(email,phone,name,password,status,regtime,root) values(?,?,?,?,?,?,?)";
                pstmt = conn.prepareStatement(sql);

                pstmt.setString(1, user.getEmail());
                pstmt.setString(2, user.getPhone());
                pstmt.setString(3, user.getName());
                pstmt.setString(4, user.getPassword());
                pstmt.setLong(5, user.getStatus());
                pstmt.setDate(6, user.getRegtime());
                pstmt.setLong(7, user.getRoot());
                pstmt.executeUpdate();
                close(pstmt,conn);
                WriterDao writerDao = new WriterDao();
                Date date = new Date();
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
                String replace = user.toString().replace("\\", " ");
                replace = replace.replace("\n", " ");
                writerDao.write("\"操作\":\"增加\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
                return true;


        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }


    }

    public boolean deleteUserByID(long id) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        User userById = getUserById(Math.toIntExact(id));
        WriterDao writerDao = new WriterDao();
        Date date = new Date();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simple.format(date.getTime());
        String replace = userById.toString().replace("\\", " ");
        replace = replace.replace("\n", " ");
        writerDao.write("\"操作\":\"删除\",\"操作时间\":\""+
                format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
            String sql = "delete from `user` where id=? ";
            pstmt = conn.prepareStatement(sql);
            pstmt.setLong(1, id);
            pstmt.executeUpdate();
            close(pstmt,conn);
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }

    }

    public boolean updateUser(User user) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
            String sql = "update `user` set email=?,phone=?,name=?,password=?,status=?,regtime=?,root=? where id=?";
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, user.getEmail());
            pstmt.setString(2, user.getPhone());
            pstmt.setString(3, user.getName());
            pstmt.setString(4, user.getPassword());
            pstmt.setLong(5, user.getStatus());
            pstmt.setDate(6, user.getRegtime());
            pstmt.setLong(7, user.getRoot());
            pstmt.setLong(8, user.getId());

            pstmt.executeUpdate();
            close(pstmt,conn);
            WriterDao writerDao = new WriterDao();
            Date date = new Date();
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = simple.format(date.getTime());
            String replace = user.toString().replace("\\", " ");
            replace = replace.replace("\n", " ");
            writerDao.write("\"操作\":\"修改\",\"操作时间\":\""+
                    format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
            return  true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }

    }
//    public User getColl(ResultSet rs) throws SQLException {
//		User user = new User();
//		user.setId(rs.getInt(1));
//		user.setEmail(rs.getString(2));
//		user.setPhone(rs.getString(3));
//		user.setName(rs.getString(4));
//		user.setPassword(rs.getString(5));
//		user.setStatus(rs.getInt(6));
//		user.setRegtime(rs.getDate(7));
//		return user;
//	}

    public ArrayList<User> isBanned(int nn) {
        ArrayList<User> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("USER");
            String sql = "select * from user where type=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,nn);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {

                list.add(getUser(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }
    }
    public ArrayList<User> isClassic9() {
		ArrayList<User> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "select * from user where root =\'0\'";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				User coll = getUser(rs);
				list.add(coll);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}
	}
	 
	public ArrayList<User> isClassic10() {
		ArrayList<User> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "select * from user where root !=\'0\'";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				User coll = getUser(rs);
				list.add(coll);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}
	}

    public ArrayList<User> isRoot(int nn) {
        ArrayList<User> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("USER");
            String sql = "select * from user where root=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,nn);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getUser(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }
    }

    public ArrayList<User> getUserByRegtime(Date date) {

        ArrayList<User> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("USER");
            String sql = "select * from user where time >=?";
            pstmt = conn.prepareStatement(sql);
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
            pstmt.setString(1, simple.format(date));
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getUser(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }
}
