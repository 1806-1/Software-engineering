
import dao.ActivityDao;
import dao.WriterDao;
import model.Activity;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;




public class LogServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

         
        }
        else{
            getALL(out);
        }
    }
    public void getALL(PrintWriter out){
    	WriterDao writerDao = new WriterDao();
    	String read = writerDao.read();
    	StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":\"\",\"data\":[");
        buffer.append(read);
        buffer.append("]}");
        out.print(buffer);
        
    }

 

 






}
