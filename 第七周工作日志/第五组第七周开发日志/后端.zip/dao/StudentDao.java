package com.wenr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.wenr.model.Student;
import com.wenr.util.DBUtil;

public class StudentDao {

	public boolean isValid(Student student) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from student where sid=? and spwd=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, student.getSid());
			pstmt.setString(2, student.getSpwd());
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				student.setSid(rs.getInt(1));
				student.setSpwd(rs.getString(2));
				student.setSname(rs.getString(3));
				student.setSex(rs.getString(4));
				student.setNation(rs.getString(5));
				student.setZhuanye(rs.getString(6));
				student.setClassn(rs.getString(7));
				student.setLianxi(rs.getString(8));
				student.setLouhao(rs.getInt(9));
				student.setQinshi(rs.getInt(10));
				return true;
			} else {
				return false;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return false;
	}

	public Student getStudentById(int sid) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select sid,sname,zhuanye,classn,lianxi,louhao,qinshi from student where sid = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sid);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				Student student = new Student();
				student.setSid(rs.getInt(1));
				student.setSname(rs.getString(2));
				student.setZhuanye(rs.getString(3));
				student.setClassn(rs.getString(4));
				student.setLianxi(rs.getString(5));
				student.setLouhao(rs.getInt(6));
				student.setQinshi(rs.getInt(7));
				return student;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return null;
	}

	public void updateremainren(int louhao, int qinshi, int remainren) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "update room set remainren=? where louhao=? and qinshi=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, remainren);
			pstmt.setInt(2, louhao);
			pstmt.setInt(3, qinshi);
			pstmt.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public int lookremainren(int louhao, int qinshi) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select remainren from room where qinshi = ? and louhao=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, qinshi);
			pstmt.setInt(2, louhao);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {

				int a = 0;
				a = rs.getInt("remainren");
				return a;
			} else
				return -1;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return -1;
	}


	public String getspwd(Student student) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();

			String sql = "select spwd from student where sid=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, student.getSid());

			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				return rs.getString(1);
			} else
				return null;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return null;

	}
	public String getlian(Student student) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();

			String sql = "select lianxi from student where sid=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, student.getSid());

			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				return rs.getString(1);
			} else
				return null;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return null;

	}
	public boolean updateStudent(Student student) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;

		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			int a1 = student.getLouhao();
			int b1 = student.getQinshi();
			int ren = lookremainren(a1, b1);
			if (ren >= 0) {
				String sql2 = "select louhao,qinshi from student where sid=?";
				pstmt2 = conn.prepareStatement(sql2);
				pstmt2.setInt(1, student.getSid());
				rs = pstmt2.executeQuery();
				if (rs != null && rs.next()) {
					int a = rs.getInt("louhao");
					int b = rs.getInt("qinshi");

					if (a == a1 && b == b1) {
						String sql = "update student set sname=?,zhuanye=? ,classn=?,lianxi=?,louhao=?,qinshi=? where sid=?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setString(1, student.getSname());
						pstmt.setString(2, student.getZhuanye());
						pstmt.setString(3, student.getClassn());
						pstmt.setString(4, student.getLianxi());
						pstmt.setInt(5, student.getLouhao());
						pstmt.setInt(6, student.getQinshi());
						pstmt.setInt(7, student.getSid());
						pstmt.executeUpdate();
						return true;
					}

					else {
						if (ren > 0) {
							updateremainren(a, b, lookremainren(a, b) + 1);
							updateremainren(a1, b1, ren - 1);
							String sql = "update student set sname=?,zhuanye=? ,classn=?,lianxi=?,louhao=?,qinshi=? where sid=?";
							pstmt = conn.prepareStatement(sql);
							pstmt.setString(1, student.getSname());
							pstmt.setString(2, student.getZhuanye());
							pstmt.setString(3, student.getClassn());
							pstmt.setString(4, student.getLianxi());
							pstmt.setInt(5, student.getLouhao());
							pstmt.setInt(6, student.getQinshi());
							pstmt.setInt(7, student.getSid());
							pstmt.executeUpdate();
							return true;
						} else
							return false;

					}
				} else
					return false;
			} else
				return false;

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public boolean updateStudent2(Student student) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			String sql = "update student set spwd=?,lianxi=? where sid=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, student.getSpwd());
			pstmt.setString(2, student.getLianxi());
			pstmt.setInt(3, student.getSid());
			pstmt.executeUpdate();
			return true;

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public boolean addStudent(Student student) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			String sql1 = "select remainren from room where louhao=? and qinshi=?";
			pstmt = conn.prepareStatement(sql1);
			pstmt.setInt(1, student.getLouhao());
			pstmt.setInt(2, student.getQinshi());
			rs = pstmt.executeQuery();

			if (rs.next()) {
				int i = rs.getInt("remainren");
				if (i > 0) {
					String sql = "insert into student(sid,sname,sex,nation,zhuanye,classn,lianxi,louhao,qinshi) values(?,?,?,?,?,?,?,?,?)";
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, student.getSid());
					pstmt.setString(2, student.getSname());
					pstmt.setString(3, student.getSex());
					pstmt.setString(4, student.getNation());
					pstmt.setString(5, student.getZhuanye());
					pstmt.setString(6, student.getClassn());
					pstmt.setString(7, student.getLianxi());
					pstmt.setInt(8, student.getLouhao());
					pstmt.setInt(9, student.getQinshi());
					updateremainren(
							student.getLouhao(),
							student.getQinshi(),
							lookremainren(student.getLouhao(),
									student.getQinshi()) - 1);
					pstmt.executeUpdate();
					return true;
				} else
					return false;

			} else {
				return false;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public String getjiaofei(Student student) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();

			String sql = "select jiaofei from pay where louhao =? and qinshi=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, student.getLouhao());
			pstmt.setInt(2, student.getQinshi());
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				return rs.getString(1);
			} else
				return null;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return null;

	}

	public ArrayList<Student> getStudentBysid(int sid) {

		ArrayList<Student> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from student where sid = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sid);
			rs = pstmt.executeQuery();

			if (rs != null && rs.next()) {
				Student student = new Student();
				student.setSid(rs.getInt(1));
				student.setSpwd(rs.getString(2));
				student.setSname(rs.getString(3));
				student.setSex(rs.getString(4));
				student.setNation(rs.getString(5));
				student.setZhuanye(rs.getString(6));
				student.setClassn(rs.getString(7));
				student.setLianxi(rs.getString(8));
				student.setLouhao(rs.getInt(9));
				student.setQinshi(rs.getInt(10));
				list.add(student);

			} else {
				return null;
			}
			;

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

	public ArrayList<Student> getAllStudent() {

		ArrayList<Student> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from student";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Student student = new Student();
				student.setSid(rs.getInt(1));
				student.setSpwd(rs.getString(2));
				student.setSname(rs.getString(3));
				student.setSex(rs.getString(4));
				student.setNation(rs.getString(5));
				student.setZhuanye(rs.getString(6));
				student.setClassn(rs.getString(7));
				student.setLianxi(rs.getString(8));
				student.setLouhao(rs.getInt(9));
				student.setQinshi(rs.getInt(10));
				list.add(student);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

	public ArrayList<Student> getAllStudent1() {

		ArrayList<Student> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select sid,sname,sex ,nation ,zhuanye ,classn ,lianxi,pay.louhao ,pay.qinshi  from student,pay  where student.louhao=pay.louhao and student.qinshi=pay.qinshi and pay.jiaofei=?  ORDER BY  pay.louhao asc, pay.qinshi asc,sid asc , sname, sex ,nation, zhuanye, classn ,lianxi;";
			String a = "��";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, a);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Student student = new Student();
				student.setSid(rs.getInt(1));
				// student.setSpwd(rs.getString(2));
				student.setSname(rs.getString(2));
				student.setSex(rs.getString(3));
				student.setNation(rs.getString(4));
				student.setZhuanye(rs.getString(5));
				student.setClassn(rs.getString(6));
				student.setLianxi(rs.getString(7));
				student.setLouhao(rs.getInt(8));
				student.setQinshi(rs.getInt(9));
				list.add(student);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

	public boolean checkpay(int qinshi, int louhao) {
		Connection conn = null;

		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			String sql1 = "select jiaofei  from pay where qinshi=? and louhao=?";
			pstmt1 = conn.prepareStatement(sql1);
			pstmt1.setInt(1, qinshi);
			pstmt1.setInt(2, louhao);
			rs = pstmt1.executeQuery();
			if (rs != null && rs.next()) {
				// String a=rs.getString(1);

				if (rs.getString(1).equals("��")) {
					// System.out.println(rs.getString(1));
					return true;
				}

				else {

					return false;

				}
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;

	}

	public boolean deleteStudent(int sid) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			String sql1 = "select qinshi,louhao from student where sid=?";
			pstmt1 = conn.prepareStatement(sql1);
			pstmt1.setInt(1, sid);
			rs = pstmt1.executeQuery();
			if (rs != null && rs.next()) {
				int a = rs.getInt(1);
				int b = rs.getInt(2);
				if (checkpay(a, b)) {
					updateremainren(b, a, lookremainren(b, a) + 1);
					String sql = "delete from student where sid=?";
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, sid);
					pstmt.executeUpdate();
					return true;
				} else
					return false;
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

}
