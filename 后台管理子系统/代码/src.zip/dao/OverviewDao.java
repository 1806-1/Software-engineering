package dao;

import model.Overview;
import util.DBUtil2;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author zebra 1024
 * @create 2021-04-30 16:20
 */
public class  OverviewDao {


    public  void close(PreparedStatement pstmt, Connection conn) {

        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public  void close(ResultSet rs,PreparedStatement pstmt, Connection conn ) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        close(pstmt,conn);
    }

    public ArrayList<Overview> getMuseumByName(String name) {
        ArrayList<Overview> list = new ArrayList();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from overview where bwgname = ?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getOver(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }finally {
            close(rs,pstmt,conn);
            return list;
        }



    }

    public Overview getOver(ResultSet rs) throws SQLException {


            Overview museum = new Overview();
            museum.setId(rs.getLong("id"));
            museum.setBwgname(rs.getString("bwgname"));
            museum.setIntroduction(rs.getString("introduction"));
            museum.setPhoto(rs.getString("photo"));
            museum.setAddress(rs.getString("address"));

            museum.setExhibition_num(rs.getLong("exhibition_num"));
            museum.setCollection_num(rs.getLong("collection_num"));
            museum.setComment_num(rs.getLong("comment_num"));
            museum.setJingwei(rs.getString("jingwei"));

            return museum;

    }
    
    public Overview getMuseumById(int id) {
        Overview overview = new Overview();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from overview where id = ?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            if (rs != null && rs.next()) {
                overview=getOver(rs);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }finally {
            close(rs,pstmt,conn);
            return overview;
        }
    }


    public ArrayList<Overview> getALLMuseum() {
        ArrayList<Overview> list = new ArrayList();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from overview ";

            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getOver(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }finally {
            close(rs,pstmt,conn);
            return list;
        }



    }

    public boolean addMuseum(Overview overview) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();

                String sql = "insert into `overview`( bwgname, introduction, photo, address,exhibition_num,collection_num,comment_num,jingwei) values(?,?,?,?,?,?,?,?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, overview.getBwgname());
                pstmt.setString(2, overview.getIntroduction());
                pstmt.setString(3, overview.getPhoto());
                pstmt.setString(4, overview.getAddress());
                pstmt.setLong(5, overview.getExhibition_num());
                pstmt.setLong(6, overview.getCollection_num());
                pstmt.setLong(7, overview.getComment_num());
                pstmt.setString(8, overview.getJingwei());
                pstmt.executeUpdate();
                close(pstmt,conn);
                WriterDao writerDao = new WriterDao();
                Date date = new Date();
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
                String replace = overview.toString().replace("\\", " ");
                replace = replace.replace("\n", " ");
                writerDao.write("\"操作\":\"增加\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
                return true;


        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }


    }


    public boolean deleteMuseumByID(long id) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        Overview museumById = getMuseumById(Math.toIntExact(id));
        WriterDao writerDao = new WriterDao();
        Date date = new Date();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simple.format(date.getTime());
        String replace = museumById.toString().replace("\\", " ");
        replace = replace.replace("\n", " ");
        writerDao.write("\"操作\":\"删除\",\"操作时间\":\""+
                format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "delete from `overview` where id=? ";
            pstmt = conn.prepareStatement(sql);
            pstmt.setLong(1, id);
            pstmt.executeUpdate();
            close(pstmt,conn);
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }

    }


    public boolean updateMuseum(Overview overview) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "update `overview` set bwgname=?, introduction=?, photo=?, address=?,exhibition_num=?,collection_num=?,comment_num=? ,jingwei=? where id=?";
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, overview.getBwgname());
            pstmt.setString(2, overview.getIntroduction());
            pstmt.setString(3, overview.getPhoto());
            pstmt.setString(4, overview.getAddress());

            pstmt.setLong(5, overview.getExhibition_num());
            pstmt.setLong(6, overview.getCollection_num());
            pstmt.setLong(7, overview.getComment_num());
            pstmt.setString(8, overview.getJingwei());

            pstmt.setLong(9, overview.getId());
            pstmt.executeUpdate();
            close(pstmt,conn);
            WriterDao writerDao = new WriterDao();
            Date date = new Date();
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = simple.format(date.getTime());
            String replace = overview.toString().replace("\\", " ");
            replace = replace.replace("\n", " ");
            writerDao.write("\"操作\":\"修改\",\"操作时间\":\""+
                    format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
            return  true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }

    }
}
