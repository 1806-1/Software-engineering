package com.example.login1.data;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login1.R;

import java.util.List;

//<>中内容是把泛型限定为只能使用MyViewHolder
public class CommentsAdapter extends RecyclerView.Adapter<CommentsAdapter.MyViewHolder> {

    private List<MyComments.CommentsDTO> commentsDTOList;

    //构造函数
    public CommentsAdapter(List<MyComments.CommentsDTO> commentsList) {
        this.commentsDTOList = commentsList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflater方法，把layout弄成view对象
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comment_recycler, parent, false);
        //myViewHolder把view和下边itemView对应起来
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        //item是从零开始，list也是。get list里面对应的位置。
        MyComments.CommentsDTO commentsDTO = commentsDTOList.get(position);
        holder.museumText.setText(commentsDTO.getMuseum());
        holder.contentText.setText(commentsDTO.getContent());
        holder.dateText.setText(commentsDTO.getDate());
    }

    @Override
    public int getItemCount() {
        //list的大小
        return commentsDTOList.size();
    }

    //装控件的类
    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView museumText;
        TextView contentText;
        TextView dateText;

        //不是分别传三个，传一个itemView就行
        public MyViewHolder(View itemView) {
            super(itemView);
            this.museumText = itemView.findViewById(R.id.textView_museum);
            this.contentText = itemView.findViewById(R.id.textView_content);
            this.dateText = itemView.findViewById(R.id.textView_time);
        }
    }
}
