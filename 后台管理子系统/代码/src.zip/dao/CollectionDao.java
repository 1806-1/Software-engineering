package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;
import model.Activity;
import model.Collection;
import util.DBUtil2;

public class CollectionDao {
//	public static void main(String[] args) {
//		CollectionDao collectionDao = new CollectionDao();
//		ArrayList<Collection> mu = collectionDao.getCollectionByMn("中国地质博物馆");
//        for (int i = 0; i < mu.size(); i++) {
//            System.out.println(mu.get(i).toString());
//        }
//    }


	public  void close(PreparedStatement pstmt, Connection conn) {

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public  void close(ResultSet rs,PreparedStatement pstmt, Connection conn ) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		close(pstmt,conn);
	}

	public ArrayList<Collection> getAllCollection() {

		ArrayList<Collection> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from `collection`";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Collection coll = getColl(rs);
				list.add(coll);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}


	}
	


	public ArrayList<Collection> isClassic() {
		ArrayList<Collection> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from collection where type=\'1\'";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Collection coll = getColl(rs);
				list.add(coll);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}
	}
	public ArrayList<Collection> isClassic1() {
		ArrayList<Collection> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from collection where type=\'0\'";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Collection coll = getColl(rs);
				list.add(coll);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}
	}

	public ArrayList<Collection> isClassic3() {
		ArrayList<Collection> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from collection where status=\'0\'";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Collection coll = getColl(rs);
				list.add(coll);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}
	}
	 
	public ArrayList<Collection> isClassic4() {
		ArrayList<Collection> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from collection where status=\'1\'";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Collection coll = getColl(rs);
				list.add(coll);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}
	}
	
	public Collection getCollectionById(int id) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Collection coll=null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from collection where id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				 coll = getColl(rs);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return coll;
		}
	}

	public Collection getColl(ResultSet rs) throws SQLException {
		Collection collection = new Collection();
		collection.setId(rs.getInt(1));
		collection.setMuseumName(rs.getString(2));
		collection.setType(rs.getString(3));
		collection.setColname(rs.getString(4));
		collection.setIntroduction(rs.getString(5));
		collection.setPhoto(rs.getString(6));
		collection.setStatus(rs.getInt(7));
		return collection;
	}

	public boolean updateCollection(Collection collection) 	{
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "update `collection` set museumName=?,type=?,colname=?,introduction=?,photo=?,status=? where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, collection.getMuseumName());
			pstmt.setString(2, collection.getType());
			pstmt.setString(3, collection.getColname());
			pstmt.setString(4, collection.getIntroduction());
			pstmt.setString(5, collection.getPhoto());
			pstmt.setInt(6, collection.getStatus());
			pstmt.setInt(7, collection.getId());
			pstmt.executeUpdate();
			close(pstmt,conn);
			WriterDao writerDao = new WriterDao();
			Date date = new Date();
			SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String format = simple.format(date.getTime());
			String replace = collection.toString().replace("\\", " ");
			replace = replace.replace("\n", " ");
			writerDao.write("\"操作\":\"修改\",\"操作时间\":\""+
					format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
			return  true;
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		}

	}

	public ArrayList<Collection> isLend(int id) {
		ArrayList<Collection> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from collection where status=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,id);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Collection coll = getColl(rs);
				list.add(coll);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}
	}

	public ArrayList<Collection> getCollectionByMn(String name) {

		ArrayList<Collection> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from collection where museumName = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {

				list.add(getColl(rs));
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}

	}

	public boolean addCollection(Collection collection) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "insert into collection(museumName,type,colname,introduction,photo,status) values(?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, collection.getMuseumName());
			pstmt.setString(2, collection.getType());
			pstmt.setString(3, collection.getColname());
			pstmt.setString(4, collection.getIntroduction());
			pstmt.setString(5, collection.getPhoto());
			pstmt.setInt(6, collection.getStatus());
			pstmt.executeUpdate();
			close(pstmt,conn);
			WriterDao writerDao = new WriterDao();
			Date date = new Date();
			SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String format = simple.format(date.getTime());
			String replace = collection.toString().replace("\\", " ");
			replace = replace.replace("\n", " ");
			writerDao.write("\"操作\":\"增加\",\"操作时间\":\""+
					format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
			return  true;

		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		}

	}

	public boolean deleteCollection(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		Collection collectionById = getCollectionById(id);
		WriterDao writerDao = new WriterDao();
		Date date = new Date();
		SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String format = simple.format(date.getTime());
		String replace = collectionById.toString().replace("\\", " ");
		replace = replace.replace("\n", " ");
		writerDao.write("\"操作\":\"删除\",\"操作时间\":\""+
				format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "delete from `collection` where id=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			close(pstmt, conn);
			return true;
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		}


	}


}
