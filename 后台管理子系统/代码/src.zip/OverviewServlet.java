
import dao.OverviewDao;
import dao.WriterDao;
import dao.dataDao;
import model.Comment;
import model.Overview;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;




public class OverviewServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

           if (method.equals("delete")){
               int id= Integer.parseInt(request.getParameter("id"));
               OverviewDao overviewDao = new OverviewDao();
               if (overviewDao.deleteMuseumByID(id)) {
                   out.print("yes");
               } else
                   out.print("no");
           }
           else if (method.equals("update")){
               OverviewDao overviewDao = new OverviewDao();
               System.out.println("543242424");
               if (overviewDao.updateMuseum(create(request))) {
                   out.println("yes");
               } else
                   out.println("no");
        	   
            }
           else if ("look".equals(method)){
               ArrayList<Overview> list = new ArrayList();
               OverviewDao overviewDao = new OverviewDao();
               list=overviewDao.getMuseumByName(request.getParameter("museum"));
               getOne(out,list);
            }
           else if ("add".equals(method)) {
//               ActivityDao activityDao = new ActivityDao();
//               if (activityDao.addActivity(create2(request))) {
//                   out.println("yes");
//               } else
//                   out.println("no");
               System.out.println(request.getParameter("nn"));

           }
           else if ("lookkkk".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Overview> list = new ArrayList();
               OverviewDao overviewDao = new OverviewDao();
               list=overviewDao.getMuseumByName("中国国家博物馆");
               getOne(out,list);
            }
           else if ("lookkkk1".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Overview> list = new ArrayList();
               OverviewDao overviewDao = new OverviewDao();
               list=overviewDao.getMuseumByName("北京故宫博物院");
               getOne(out,list);
            }
           else if ("lookkkk2".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Overview> list = new ArrayList();
               OverviewDao overviewDao = new OverviewDao();
               list=overviewDao.getMuseumByName("中国科学技术馆");
               getOne(out,list);
            }
           else if ("lookkkk3".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Overview> list = new ArrayList();
               OverviewDao overviewDao = new OverviewDao();
               list=overviewDao.getMuseumByName("首都博物馆");
               getOne(out,list);
            }
           else if ("lookkkk4".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Overview> list = new ArrayList();
               OverviewDao overviewDao = new OverviewDao();
               list=overviewDao.getMuseumByName("北京鲁迅博物馆");
               getOne(out,list);
            }
           else if ("lookkkk5".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Overview> list = new ArrayList();
               OverviewDao overviewDao = new OverviewDao();
               list=overviewDao.getMuseumByName("无锡博物院");
               getOne(out,list);
            }
           else if ("lookkkk6".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Overview> list = new ArrayList();
               OverviewDao overviewDao = new OverviewDao();
               list=overviewDao.getMuseumByName("陕西历史博物馆");
               getOne(out,list);
            }
            else if ("add".equals(method)) {
                OverviewDao overviewDao = new OverviewDao();
                String rootname = request.getParameter("rootname");
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                if (overviewDao.addMuseum(create2(request))) {
                    out.println("yes");
                } else
                    out.println("no");
               
 
            }
            else if ("restore".equals(method)) {
                dataDao dataDao = new dataDao();
                String data = request.getParameter("date");
                String table = request.getParameter("from");
                String rootname = request.getParameter("rootname");
                Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"恢复\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
                if (dataDao.recover(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               
 
            }
            else if ("backup".equals(method)) {
                dataDao dataDao = new dataDao();
                String data = request.getParameter("date");
                String table = request.getParameter("from");
                String rootname = request.getParameter("rootname");
                Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"备份\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
                if (dataDao.backup(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               
 
            }


        }
        else{
            getALL(out);
        }
    }
    public void getALL(PrintWriter out){
       OverviewDao overviewDao = new OverviewDao();
        ArrayList<Overview> list = overviewDao.getALLMuseum();
        getOne(out,list);
    }

    public void getOne(PrintWriter out,ArrayList<Overview> list){

        int size = list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");


        for (int i = 0; i < size; i++) {

            

            buffer.append("{\"id\":"+list.get(i).getId()+",");

            String bwgname = list.get(i).getBwgname().replace("\"", " ");
            bwgname = bwgname.replace("\n", " ");
            bwgname = bwgname.replace("\\", " ");
            buffer.append("\"bwgname\":\""+bwgname+"\",");

            String address = list.get(i).getAddress().replace("\"", " ");
            address = address.replace("\n", " ");
            address = address.replace("\\", " ");
            buffer.append("\"address\":\""+address+"\",");

            String introduction = list.get(i).getIntroduction();
            introduction=introduction.replace("\n","");
            introduction=introduction.replace("\""," ");
            introduction=introduction.replace("\\"," ");
            buffer.append("\"introduction\":\""+introduction+"\",");
            String jingwei = list.get(i).getJingwei();
            buffer.append("\"jingwei\": \""+jingwei+"\",");

            buffer.append("\"exhibition_num\":"+list.get(i).getExhibition_num()+",");

            buffer.append("\"collection_num\":"+list.get(i).getCollection_num()+",");

            buffer.append("\"comment_num\":"+list.get(i).getComment_num()+",");
            buffer.append("\"photo\":\""+list.get(i).getPhoto()+"\"}");
            if (i!=size-1)
                buffer.append(",");
        }
        buffer.append("]}");
        String s1 = new String(buffer);
        out.print(s1);
    }

    public Overview create(HttpServletRequest request) {
        Overview overview = new Overview();
        overview.setJingwei(request.getParameter("jingwei"));
        overview.setExhibition_num(Integer.parseInt(request.getParameter("exhibition_num")));
        overview.setCollection_num(Integer.parseInt(request.getParameter("collection_num")));
        overview.setComment_num(Integer.parseInt(request.getParameter("comment_num")));
        overview.setId(Integer.parseInt(request.getParameter("id")));
        overview.setBwgname(request.getParameter("bwgname"));
        overview.setAddress(request.getParameter("address"));
        overview.setIntroduction(request.getParameter("introduction"));
        overview.setPhoto(request.getParameter("photo"));
        return overview;
    }

    public Overview create2(HttpServletRequest request) {
        Overview overview = new Overview();
        overview.setJingwei(request.getParameter("jingwei"));
        overview.setExhibition_num(Integer.parseInt(request.getParameter("exhibition_num")));
        overview.setCollection_num(Integer.parseInt(request.getParameter("collection_num")));
        overview.setComment_num(Integer.parseInt(request.getParameter("comment_num")));
        overview.setBwgname(request.getParameter("bwgname"));
        overview.setAddress(request.getParameter("address"));
        overview.setIntroduction(request.getParameter("introduction"));
        overview.setPhoto(request.getParameter("photo"));
        return overview;
    }

}
