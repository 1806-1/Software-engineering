package com.wenr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.wenr.dao.StudentDao;
import com.wenr.model.Student;

public class StudentServlet extends HttpServlet {

	public StudentServlet() {
		super();
	}

	public void destroy() {
		super.destroy();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String action = request.getParameter("action");
		PrintWriter out = response.getWriter();
		if ("update".equals(action)) {
			Student student = new Student();
			StudentDao studentDao = new StudentDao();

			student.setSid(Integer.parseInt(request.getParameter("sid")));
			student.setSpwd(request.getParameter("spwd"));

			student.setLianxi(request.getParameter("lianxi"));

			if (studentDao.updateStudent2(student)) {
				out.println("<h1>�޸ĳɹ���</h1>");
			} else

				out.println("<h1>�޸�ʧ�ܣ�</h1>");

			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/studentSelected.jsp\">����</a>");

		}
	}

}
