package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ExplainDao;
import model.Explain;


public class ExplainServlet extends HttpServlet {

    public ExplainServlet() {super();
    }

    public void destroy() {
        super.destroy();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String action = request.getParameter("action");
        PrintWriter out = response.getWriter();
        if ("add".equals(action)) {
            ExplainDao ExplainDao = new ExplainDao();
            if (ExplainDao.addExplain(create(request))) {
                out.println("<h1>添加成功！</h1>");
            } else
                out.println("<h1>添加失败！</h1>");

            //out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/studentSelected.jsp\">返回</a>");
        }
        else if ("update".equals(action)){
            ExplainDao ExplainDao = new ExplainDao();
            if (ExplainDao.updateExplain(create(request))) {
                out.println("<h1>修改成功！</h1>");
            } else
                out.println("<h1>修改失败！</h1>");
        }
        else if ("delete".equals(action)){
            ExplainDao ExplainDao = new ExplainDao();
            if (ExplainDao.deleteExplain(Integer.parseInt(request.getParameter("id")))) {
                out.println("<h1>修改成功！</h1>");
            } else
                out.println("<h1>修改失败！</h1>");
        }
        else if ("getId".equals(action)){
            int[] ints = new int[2];
            ExplainDao ExplainDao = new ExplainDao();
            ints=ExplainDao.getExplainTypeI(Integer.parseInt(request.getParameter("id")));
            if (ints != null) {
                request.setAttribute("ExplainId", ints);
                //  request.getRequestDispatcher("../adminSearchRoom2.jsp")
                //        .forward(request, response);
            } else
                out.println("<h1>查询失败</h1>");
            //out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchRoom.jsp\">返回</a>");
        }
        else if ("getName".equals(action)){
            String s = new String();
            ExplainDao ExplainDao = new ExplainDao();
            s=ExplainDao.getExplainTypeS(Integer.parseInt(request.getParameter("id")));
            if (s != null) {
                request.setAttribute("ExplainName", s);
                //  request.getRequestDispatcher("../adminSearchRoom2.jsp")
                //        .forward(request, response);
            } else
                out.println("<h1>查询失败</h1>");
            //out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchRoom.jsp\">返回</a>");
        }
        else if ("getByUserId".equals(action)){
            ArrayList<Explain> list = new ArrayList();
            ExplainDao ExplainDao = new ExplainDao();
            list=ExplainDao.getExplainByUserId(Integer.parseInt(request.getParameter("id")));
            if (list != null) {
                request.setAttribute("ExplainList", list);
                //request.getRequestDispatcher("../adminSearchRoom2.jsp")
                //  .forward(request, response);
            } else
                out.println("<h1>查询失败</h1>");
            //out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchRoom.jsp\">返回</a>");
        }

    }

    public Explain create(HttpServletRequest request) {
        Explain Explain = new Explain();
        Explain.setId(Integer.parseInt(request.getParameter("id")));
        Explain.setType(Integer.parseInt(request.getParameter("type")));
        Explain.setMuseumID(Integer.parseInt(request.getParameter("museumID")));
        Explain.setExhibitionID(Integer.parseInt(request.getParameter("exhibitionID")));
        Explain.setCollectionID(Integer.parseInt(request.getParameter("collectionID")));
        Explain.setName(request.getParameter("name"));
        Explain.setUserID(Integer.parseInt(request.getParameter("userID")));
        Explain.setIntroduction(request.getParameter("introduction"));
        Explain.setAudio(request.getParameter("audio"));
        Explain.setStatus(Integer.parseInt(request.getParameter("status")));
        return Explain;
    }

}
