package com.wenr.dao;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import com.wenr.model.Student;
import com.wenr.model.Teacher;
import com.wenr.util.DBUtil;

public class TeacherDao {

	public ArrayList<Teacher> getAllTeacher() {

		ArrayList<Teacher> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from pay";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Teacher teacher = new Teacher();
				teacher.setLouhao(rs.getInt(1));
				teacher.setQinshi(rs.getInt(2));
				teacher.setBianhao(rs.getInt(3));
				teacher.setTime(rs.getString(4));
				teacher.setType(rs.getString(5));
				teacher.setJine(rs.getInt(6));
				teacher.setJiaofei(rs.getString(7));
				list.add(teacher);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

	public ArrayList<Teacher> getTeacherby(int qinshi, int louhao) {

		ArrayList<Teacher> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from pay where qinshi = ? and louhao=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, qinshi);
			pstmt.setInt(2, louhao);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				Teacher teacher = new Teacher();
				teacher.setLouhao(rs.getInt(1));
				teacher.setQinshi(rs.getInt(2));
				teacher.setBianhao(rs.getInt(3));
				teacher.setTime(rs.getString(4));
				teacher.setType(rs.getString(5));
				teacher.setJine(rs.getInt(6));
				teacher.setJiaofei(rs.getString(7));
				list.add(teacher);
			} else
				return null;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}
	public ArrayList<Student> getTeacherby2(int qinshi, int louhao) {

		ArrayList<Student> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select sid,sname,sex ,nation ,zhuanye ,classn ,lianxi,louhao ,qinshi  from student where louhao=? and qinshi =?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, louhao);
			pstmt.setInt(2, qinshi);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Student student = new Student();
				student.setSid(rs.getInt(1));
				// student.setSpwd(rs.getString(2));
				student.setSname(rs.getString(2));
				student.setSex(rs.getString(3));
				student.setNation(rs.getString(4));
				student.setZhuanye(rs.getString(5));
				student.setClassn(rs.getString(6));
				student.setLianxi(rs.getString(7));
				student.setLouhao(rs.getInt(8));
				student.setQinshi(rs.getInt(9));
				list.add(student);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

	public boolean re() {
		Connection conn = null;
		PreparedStatement pstmt1 = null;
		try {
			conn = DBUtil.getConnection();
			String sql1 = "update pay set jiaofei=? ";
			pstmt1 = conn.prepareStatement(sql1);
			pstmt1.setString(1, "��");
			pstmt1.executeUpdate();
			return true;

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public int checkroom(int louhao, int qinshi) {
		Connection conn = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			String sql1 = "select count(sid) from student where louhao=? and qinshi=?";
			pstmt1 = conn.prepareStatement(sql1);
			pstmt1.setInt(1, louhao);
			pstmt1.setInt(2, qinshi);
			rs = pstmt1.executeQuery();
			if (rs != null && rs.next()) {
				int b = rs.getInt("count(sid)");

				return b;
			} else
				return -1;

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return -1;
	}

	public boolean deleteTeacher(int qinshi, int louhao) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			if (checkroom(louhao, qinshi) == 0) {
				conn = DBUtil.getConnection();
				String sql = "delete from pay where qinshi=? and louhao=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, qinshi);
				pstmt.setInt(2, louhao);
				pstmt.executeUpdate();
				return true;
			} else
				return false;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public void queren(int qinshi, int louhao) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateNowStr = sdf.format(d);
		try {
			conn = DBUtil.getConnection();
			String sql1 = "select max(bianhao) from pay ";
			pstmt1 = conn.prepareStatement(sql1);
			rs = pstmt1.executeQuery();
			int b = 1000000;
			if (rs != null && rs.next()) {

				b = rs.getInt("max(bianhao)");
				if (b == 0)
					b = 1000000;
				else
					b += 1;
			}
			conn = DBUtil.getConnection();
			String sql = "update pay set bianhao=?,time=? ,jiaofei=? where qinshi=? and louhao=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, b);
			pstmt.setString(2, dateNowStr);
			pstmt.setString(3, "��");
			pstmt.setInt(4, qinshi);
			pstmt.setInt(5, louhao);
			pstmt.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}

	}
}
