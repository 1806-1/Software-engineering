package com.example.login1.data;

import java.util.List;

public class MyComments {

    private static int number;
    private static List<CommentsDTO> comments;

    //get和set
    public static int getNumber() {
        return number;
    }
    public void setNumber(int number) {
        this.number = number;
    }

    public static List<CommentsDTO> getComments() {
        return comments;
    }
    public void setComments(List<CommentsDTO> comments) {
        this.comments = comments;
    }

    //内部实体类？
    public static class CommentsDTO {
        private String date;
        private String museum;
        private String content;

        public String getDate() {
            return date;
        }
        public void setDate(String date) {
            this.date = date;
        }

        public String getMuseum() {
            return museum;
        }
        public void setMuseum(String museum) {
            this.museum = museum;
        }

        public String getContent() {
            return content;
        }
        public void setContent(String content) {
            this.content = content;
        }
    }
}