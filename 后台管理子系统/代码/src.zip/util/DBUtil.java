package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private  final String driver = "com.mysql.cj.jdbc.Driver";
	private  final String url = "jdbc:mysql://182.92.221.222:3306/";
	private  final String shuXing="?useUnicode=true&characterEncoding=utf8&useSSL=true";
	private  final String username = "root";
	private  final String password = "CS1806se.";

	private  Connection conn;


	{
		try {
			Class.forName(driver);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}



	public  Connection getConnection() throws SQLException {

		if (conn == null) {
			conn = DriverManager.getConnection(url+"MUSEUM", username, password);
			return conn;
		}
		return conn;
	}
	public  Connection getConnection(String name) throws SQLException {
		if (conn == null) {
			conn = DriverManager.getConnection(url+name, username, password);
			return conn;
		}
		return conn;
	}

}
