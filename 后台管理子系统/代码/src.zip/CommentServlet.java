
import dao.CommentDao;
import dao.WriterDao;
import dao.dataDao;
import model.Comment;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;




public class CommentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

           if (method.equals("delete")){
               int id= Integer.parseInt(request.getParameter("id"));
               CommentDao commentDao = new CommentDao();
               if (commentDao.deleteComment(id)) {
                   out.print("yes");
               } else
                   out.print("no");
           }
           else if (method.equals("update")){
               CommentDao commentDao = new CommentDao();
               System.out.println("543242424");
               if (commentDao.updateComment(create(request))) {
                   out.println("yes");
               } else
                   out.println("no");
        	   
            }
           else if ("look".equals(method)){
               ArrayList<Comment> list = new ArrayList();
               CommentDao commentDao = new CommentDao();
               list=commentDao.getCommentByMuseumN(request.getParameter("museum"));
               getOne(out,list);
            }
           else if ("add".equals(method)) {
//               ActivityDao activityDao = new ActivityDao();
//               if (activityDao.addActivity(create2(request))) {
//                   out.println("yes");
//               } else
//                   out.println("no");
               System.out.println(request.getParameter("nn"));

           }
           else if ("lookkkk".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Comment> list = new ArrayList();
               CommentDao commentDao = new CommentDao();
               list=commentDao.getCommentByMuseumN("中国国家博物馆");
               getOne(out,list);
            }
           else if ("lookkkk1".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Comment> list = new ArrayList();
               CommentDao commentDao = new CommentDao();
               list=commentDao.getCommentByMuseumN("北京故宫博物院");
               getOne(out,list);
            }
           else if ("lookkkk2".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Comment> list = new ArrayList();
               CommentDao commentDao = new CommentDao();
               list=commentDao.getCommentByMuseumN("中国科学技术馆");
               getOne(out,list);
            }
           else if ("lookkkk3".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Comment> list = new ArrayList();
               CommentDao commentDao = new CommentDao();
               list=commentDao.getCommentByMuseumN("首都博物馆");
               getOne(out,list);
            }
           else if ("lookkkk4".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Comment> list = new ArrayList();
               CommentDao commentDao = new CommentDao();
               list=commentDao.getCommentByMuseumN("北京鲁迅博物馆");
               getOne(out,list);
            }
           else if ("lookkkk5".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Comment> list = new ArrayList();
               CommentDao commentDao = new CommentDao();
               list=commentDao.getCommentByMuseumN("无锡博物院");
               getOne(out,list);
            }
           else if ("lookkkk6".equals(method)){
        	   System.out.println("3333333333hhhhhhhhhh");
               ArrayList<Comment> list = new ArrayList();
               CommentDao commentDao = new CommentDao();
               list=commentDao.getCommentByMuseumN("陕西历史博物馆");
               getOne(out,list);
            }
            else if ("add".equals(method)) {
                CommentDao commentDao = new CommentDao();
                String rootname = request.getParameter("rootname");
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                if (commentDao.addComment(create2(request))) {
                    out.println("yes");
                } else
                    out.println("no");
               
 
            }
            else if ("restore".equals(method)) {
                dataDao dataDao = new dataDao();
                String data = request.getParameter("date");
                String table = request.getParameter("from");
                String rootname = request.getParameter("rootname");
                Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"恢复\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
                if (dataDao.recover(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               
 
            }
            else if ("backup".equals(method)) {
                dataDao dataDao = new dataDao();
                String data = request.getParameter("date");
                String table = request.getParameter("from");
                String rootname = request.getParameter("rootname");
                Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"备份\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
                if (dataDao.backup(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               
 
            }


        }
        else{
            getALL(out);
        }
    }
    public void getALL(PrintWriter out){
        CommentDao commentDao = new CommentDao();
        ArrayList<Comment> list = commentDao.getAllComment();
        getOne(out,list);
    }

    public void getOne(PrintWriter out,ArrayList<Comment> list){

        int size = list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");


        for (int i = 0; i < size; i++) {
            buffer.append("{\"id\":"+list.get(i).getId()+",");

            buffer.append("\"userID\":"+list.get(i).getUserID()+",");

            String userName = list.get(i).getUserName().replace("\""," ").trim();
            userName = userName.replace("\n"," ").trim();
            userName = userName.replace("\\"," ").trim();
            buffer.append("\"userName\": \""+userName+"\",");

            buffer.append("\"museumID\":"+list.get(i).getMuseumID()+",");

            String museumName = list.get(i).getMuseumName().replace("\"", " ").trim();
            museumName = museumName.replace("\n", " ").trim();
            museumName = museumName.replace("\\", " ").trim();
            buffer.append("\"museumName\":\""+museumName+"\",");

            buffer.append("\"score0\":"+list.get(i).getScore0()+",");

            buffer.append("\"score1\":"+list.get(i).getScore1()+",");

            buffer.append("\"score2\":"+list.get(i).getScore2()+",");

            String discuss = list.get(i).getDiscuss().replace("\"", " ").trim();
            discuss = discuss.replace("\n", " ").trim();
            discuss = discuss.replace("\\", " ").trim();
            buffer.append("\"discuss\":\""+discuss+"\",");

            buffer.append("\"time\":\""+simple.format(list.get(i).getTime())+"\",");

            buffer.append("\"status\":"+list.get(i).getStatus()+"}");
            if (i!=size-1)
                buffer.append(",");

        }
        buffer.append("]}");
        String s1 = new String(buffer);
        out.print(s1);
    }

    public Comment create(HttpServletRequest request) {
        Comment comment = new Comment();
        comment.setId(Integer.parseInt(request.getParameter("id")));
        comment.setUserID(Integer.parseInt(request.getParameter("userID")));
        comment.setUserName(request.getParameter("userName"));
        comment.setMuseumID(Integer.parseInt(request.getParameter("museumID")));
        comment.setMuseumName(request.getParameter("museumName"));
        comment.setScore0(Integer.parseInt(request.getParameter("score0")));
        comment.setScore1(Integer.parseInt(request.getParameter("score1")));
        comment.setScore2(Integer.parseInt(request.getParameter("score2")));
        comment.setDiscuss(request.getParameter("discuss"));
        comment.setTime(Date.valueOf(request.getParameter("time")));
        comment.setStatus(Integer.parseInt(request.getParameter("status")));
        return comment;
    }

    public Comment create2(HttpServletRequest request) {
        Comment comment = new Comment();
        comment.setUserID(Integer.parseInt(request.getParameter("userID")));
        comment.setUserName(request.getParameter("userName"));
        comment.setMuseumID(Integer.parseInt(request.getParameter("museumID")));
        comment.setMuseumName(request.getParameter("museumName"));
        comment.setScore0(Integer.parseInt(request.getParameter("score0")));
        comment.setScore1(Integer.parseInt(request.getParameter("score1")));
        comment.setScore2(Integer.parseInt(request.getParameter("score2")));
        comment.setDiscuss(request.getParameter("discuss"));
        comment.setTime(Date.valueOf(request.getParameter("time")));
        comment.setStatus(Integer.parseInt(request.getParameter("status")));
        return comment;
    }

}
