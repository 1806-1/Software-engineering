package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


import model.Collection;
import model.Comment;
import util.DBUtil2;

public class CommentDao {
//    public static void main(String[] args) {
//        CommentDao commentDao = new CommentDao();
//		ArrayList<Comment> museumN = commentDao.getCommentByMuseumN("中国地质博物馆");
//		for (int i = 0; i < museumN.size(); i++) {
//			System.out.println(museumN.toString());
//		}
//	}


	public  void close(PreparedStatement pstmt, Connection conn) {

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public  void close(ResultSet rs,PreparedStatement pstmt, Connection conn ) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		close(pstmt,conn);
	}

	public Comment getComm(ResultSet rs) throws SQLException {
		Comment comment = new Comment();
		comment.setId(rs.getInt(1));
		comment.setUserID(rs.getInt(2));
		comment.setUserName(rs.getString(3));
		comment.setMuseumID(rs.getInt(4));
		comment.setMuseumName(rs.getString(5));
		comment.setScore0(rs.getInt(6));
		comment.setScore1(rs.getInt(7));
		comment.setScore2(rs.getInt(8));
		comment.setDiscuss(rs.getString(9));
		comment.setTime(rs.getDate(10));
		comment.setStatus(rs.getInt(11));
		return comment;
	}

	public ArrayList<Comment> getAllComment() {

		ArrayList<Comment> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "select * from `comment`";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				list.add(getComm(rs));
			}


		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}


	}

	public Comment getCommentById(int id) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Comment comment = new Comment();
		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "select * from `comment` where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				comment = getComm(rs);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return comment;
		}


	}

	public boolean addComment(Comment Comment) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");

				String sql = "insert into `comment`(userID,userName,museumID,museumName,score0,score1,score2,discuss,time,status) values(?,?,?,?,?,?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Comment.getUserID());
				pstmt.setString(2, Comment.getUserName());
				pstmt.setInt(3, Comment.getMuseumID());
				pstmt.setString(4, Comment.getMuseumName());
				pstmt.setInt(5, Comment.getScore0());
				pstmt.setInt(6, Comment.getScore1());
				pstmt.setInt(7, Comment.getScore2());
				pstmt.setString(8, Comment.getDiscuss());
				pstmt.setDate(9, Comment.getTime());
				pstmt.setInt(10, Comment.getStatus());
				pstmt.executeUpdate();
				close(pstmt,conn);
			WriterDao writerDao = new WriterDao();
			Date date = new Date();
			SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String format = simple.format(date.getTime());
			String replace = Comment.toString().replace("\\", " ");
			replace = replace.replace("\n", " ");
			writerDao.write("\"操作\":\"增加\",\"操作时间\":\""+
					format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
				return true;


		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {

		}
		return false;
	}

	public boolean updateComment(Comment Comment) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "update `comment` set userID=?,userName=?,museumID=?,museumName=?,score0=?,score1=?,score2=?,discuss=?,time=?,status=? where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Comment.getUserID());
			pstmt.setString(2, Comment.getUserName());
			pstmt.setInt(3, Comment.getMuseumID());
			pstmt.setString(4, Comment.getMuseumName());
			pstmt.setInt(5, Comment.getScore0());
			pstmt.setInt(6, Comment.getScore1());
			pstmt.setInt(7, Comment.getScore2());
			pstmt.setString(8, Comment.getDiscuss());
			pstmt.setDate(9, Comment.getTime());
			pstmt.setInt(10, Comment.getStatus());
			pstmt.executeUpdate();
			close(pstmt,conn);
			WriterDao writerDao = new WriterDao();
			Date date = new Date();
			SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String format = simple.format(date.getTime());
			String replace = Comment.toString().replace("\\", " ");
			replace = replace.replace("\n", " ");
			writerDao.write("\"操作\":\"修改\",\"操作时间\":\""+
					format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
			return true;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return false;
	}

	public boolean deleteComment(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		Comment commentById = getCommentById(id);
		WriterDao writerDao = new WriterDao();
		Date date = new Date();
		SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String format = simple.format(date.getTime());
		String replace = commentById.toString().replace("\\", " ");
		replace = replace.replace("\n", " ");
		writerDao.write("\"操作\":\"删除\",\"操作时间\":\""+
				format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "delete from `comment` where id=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			return true;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public ArrayList<Comment> getCommentByUserN(String name) {

		ArrayList<Comment> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "select * from `comment` where userName=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				list.add(getComm(rs));
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}


	}

	public ArrayList<Comment> getCommentByMuseumN(String name) {

		ArrayList<Comment> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "select * from `comment` where museumName=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				list.add(getComm(rs));
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}

	}

	public ArrayList<Comment> geCommentByTime(Date date) {

		ArrayList<Comment> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "select * from comment where time >=?";
			pstmt = conn.prepareStatement(sql);
			SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
			pstmt.setString(1, simple.format(date));
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				list.add(getComm(rs));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
		    close(rs,pstmt,conn);
		}

		return list;
	}

	public ArrayList<Comment> getCommentByTime(Date date1,Date date2) {

		ArrayList<Comment> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection("USER");
			String sql = "select * from comment where time between ? and ?";
			pstmt = conn.prepareStatement(sql);
			SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
			pstmt.setString(1, simple.format(date1));
			pstmt.setString(2, simple.format(date2));
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				list.add(getComm(rs));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
		}

		return list;
	}

	public ArrayList<Comment> isApproved(int id) {
		ArrayList<Comment> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
			String sql = "select * from comment where status=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,id);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Comment comm = getComm(rs);
				list.add(comm);
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs,pstmt,conn);
			return list;
		}
	}


}
