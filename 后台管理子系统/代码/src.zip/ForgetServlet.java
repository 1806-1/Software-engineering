
import dao.ForgetDao;
import dao.UserDao;
import model.Forget;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class ForgetServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        ForgetDao forgetDao = new ForgetDao();
        PrintWriter out = response.getWriter();

        if(method!=null){

            if (method.equals("update")){
               if (forgetDao.updateForget(create(request))){
                   out.print("yes");
               }
               else
                   out.print("no");
            }
            else if ("get".equals(method)){
                String name = request.getParameter("name");
                Forget forget = forgetDao.get(name);
                getOne(out,forget);

            }
            else if ("add".equals(method)) {
                if (forgetDao.addForget(create(request))){
                    out.print("yes");
                }
                else
                    out.print("no");
            }
            else if ("getPassword".equals(method)){
                String name = request.getParameter("name");
                UserDao userDao = new UserDao();
                String userPass = userDao.getUserPass(name);
                if (!userPass.equals(null))
                    out.print(userPass);
                else
                    out.print("no");

            }
            else if ("setPassword".equals(method)){
                String name = request.getParameter("name");
                String password = request.getParameter("password");
                UserDao userDao = new UserDao();
                System.out.println(name);
                System.out.println(password);
                if (userDao.setUserPass(name,password))
                    out.print("yes");
                else
                    out.print("no");
            }
            else if ("isTrue".equals(method)){


                if (forgetDao.isTrue(create(request))>0){
                    String name = request.getParameter("name");
                    UserDao userDao = new UserDao();
                    String userPass = userDao.getUserPass(name);
                    out.print(userPass);
                }
                else
                    out.print("no");
            }
        }

    }

    public void getOne(PrintWriter out,Forget forget){

        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":2,\"data\":[");

        buffer.append("{\"id\":"+forget.getId()+",");
        String name = forget.getName().replace("\""," ").trim();
        buffer.append("\"name\": \""+name+"\",");
        buffer.append("\"name\": \""+forget.getQuestion1()+"\",");
        buffer.append("\"name\": \""+forget.getQuestion2()+"\",");
        buffer.append("\"name\": \""+forget.getQuestion3()+"\"}");

        buffer.append("]}");
        String s1 = new String(buffer);
        out.print(s1);
    }

    public Forget create(HttpServletRequest request) {
        Forget forget = new Forget();
        forget.setName(request.getParameter("name"));
        forget.setQuestion1(request.getParameter("question1"));
        forget.setQuestion2(request.getParameter("question2"));
        forget.setQuestion3(request.getParameter("question3"));
        return forget;
    }


}
