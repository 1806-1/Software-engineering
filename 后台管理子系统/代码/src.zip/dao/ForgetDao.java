package dao;

import model.Forget;
import util.DBUtil2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ForgetDao {
    public  void close(PreparedStatement pstmt, Connection conn) {

        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public  void close(ResultSet rs, PreparedStatement pstmt, Connection conn ) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        close(pstmt,conn);
    }

    public Forget getFor(ResultSet rs) throws SQLException {
        Forget forget = new Forget();
        forget.setId(rs.getInt("id"));
        forget.setName(rs.getString("name"));
        forget.setQuestion1(rs.getString("question1"));
        forget.setQuestion2(rs.getString("question2"));
        forget.setQuestion3(rs.getString("question3"));
        return forget;
    }

    public Forget get(String name){

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Forget fo=null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("DATA");
            String sql = "select * from forget where name = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            if (rs != null && rs.next()) {
                fo = getFor(rs);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return fo;
        }
    }

    public boolean updateForget(Forget forget) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("DATA");
            String sql = "update `forget` set question1=?,question2=?,question3=? where name=?";
            pstmt = change(forget, conn, sql);
            pstmt.executeUpdate();
            close(pstmt,conn);
            return true;
        } catch (SQLException ex) {
            return false;
        }


    }

    public boolean addForget(Forget forget) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("DATA");
            String sql = "insert into forget(question1,question2,question3,name) values(?,?,?,?)";
            pstmt = change(forget, conn, sql);
            pstmt.executeUpdate();
            close(pstmt,conn);
            return true;
        } catch (SQLException ex) {
            return false;
        }

    }

    public PreparedStatement change(Forget forget, Connection conn, String sql) throws SQLException {
        PreparedStatement pstmt;
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, forget.getQuestion1());
        pstmt.setString(2, forget.getQuestion2());
        pstmt.setString(3,forget.getQuestion3());
        pstmt.setString(4,forget.getName());
        return pstmt;
    }


    public int isTrue(Forget forget) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int ii=-1;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection("DATA");
            String sql = "select id from forget where question1=? and question2=? and question3=? and name=?";
            pstmt = change(forget, conn, sql);
            rs = pstmt.executeQuery();
            if (rs != null && rs.next()) {
                 ii = rs.getInt(1);
            }

        }  catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return ii;
        }

    }
}
