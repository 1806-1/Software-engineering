
import dao.NewsDao;
import dao.WriterDao;
import dao.dataDao;
import model.News;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


@WebServlet(name="NewsServlet",
        urlPatterns={"/WebApp/NewsServlet"}
        )

public class NewsServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

            if (method.equals("delete")){
                int id= Integer.parseInt(request.getParameter("id"));
                String rootname = request.getParameter("rootname");
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                NewsDao newsDao = new NewsDao();
                if (newsDao.deleteNewsByID(id)) {
                    out.print("yes");
                } else
                    out.print("no");
            }
            if (method.equals("update")){
                NewsDao newsDao = new NewsDao();
                String rootname = request.getParameter("rootname");
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (newsDao.updateNews(create(request))) {
                   out.println("yes");
               } else
                   out.println("no");
            }
            else if ("look".equals(method)){
                ArrayList<News> list = new ArrayList();
                NewsDao newsDao = new NewsDao();
                list=newsDao.getNewsByMuseum(request.getParameter("museum"));
                getOne(out,list);
             }
            else if ("add".equals(method)) {
                NewsDao newsDao = new NewsDao();
                String rootname = request.getParameter("rootname");
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                if (newsDao.addNews(create2(request))) {
                    out.println("yes");
                } else
                   out.println("no");
                
            }
            else if ("lookkkk".equals(method)){
                System.out.println("3333333333hhhhhhhhhh");
                ArrayList<News> list = new ArrayList();
                NewsDao newsDao = new NewsDao();
                list=newsDao.getNewsByMuseum("中国国家博物馆");
                getOne(out,list);
             }
            else if ("restore".equals(method)) {
         	   dataDao dataDao = new dataDao();
         	   String data = request.getParameter("date");
         	   String table = request.getParameter("from");
         	   String rootname = request.getParameter("rootname");
         	   Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
         	   WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"恢复\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
         	   if (dataDao.recover(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               

            }
            else if ("backup".equals(method)) {
         	   dataDao dataDao = new dataDao();
         	   String data = request.getParameter("date");
         	   String table = request.getParameter("from");
         	   String rootname = request.getParameter("rootname");
         	   Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
         	   WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"备份\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
                if (dataDao.backup(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               

            }
           
 
         }
         else{
             getALL(out);
         }
     }
     public void getALL(PrintWriter out){
        NewsDao newsDao = new NewsDao();
        ArrayList<News> list = newsDao.getAllNews();
        getOne(out,list);
    }

    public void getOne(PrintWriter out,ArrayList<News> list){

        int size = list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");

        for (int i = 0; i < size; i++) {
            buffer.append("{\"id\":"+list.get(i).getId()+",");
            String asd=list.get(i).getMuseum().replace("\"", "").trim();
            buffer.append("\"museum\":\""+asd+"\",");
            buffer.append("\"time\":\""+simple.format(list.get(i).getTime())+"\",");
            String replace = list.get(i).getType().replace("\"", " ");
            buffer.append("\"type\":\""+replace+"\",");
            String intee = list.get(i).getContent();
            intee=intee.replace("\n","");
            intee=intee.replace("\""," ");
            intee=intee.replace("\'"," ");
            intee=intee.replace("\\"," ");
            buffer.append("\"content\":\""+intee+"\",");
            replace = list.get(i).getSource().replace("\"", " ");
            buffer.append("\"source\":\""+replace+"\",");
            replace = list.get(i).getPhoto().replace("\"", " ");
            buffer.append("\"photo\":\""+replace+"\"}");
            if (i!=size-1)
                buffer.append(",");
            
        }
        buffer.append("]}");
        String s1 = new String(buffer);
        System.out.println(s1);
        out.print(s1);


    }

   

    public News create(HttpServletRequest request) {
        News news = new News();
        news.setId(Integer.parseInt(request.getParameter("id")));
        news.setMuseum(request.getParameter("museum"));
        news.setTime(Date.valueOf(request.getParameter("time")));
        news.setType(request.getParameter("type"));
        news.setContent(request.getParameter("content"));
        news.setPhoto(request.getParameter("photo"));
        news.setSource(request.getParameter("source"));
        return news;
    }

    public News create2(HttpServletRequest request) {
        News news = new News();
        news.setMuseum(request.getParameter("museum"));
        news.setTime(Date.valueOf(request.getParameter("time")));
        news.setType(request.getParameter("type"));
        news.setContent(request.getParameter("content"));
        news.setPhoto(request.getParameter("photo"));
        news.setSource(request.getParameter("source"));
        return news;
    }







}
