package dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriterDao {
    public Boolean write(String content,String s){
        try {
            File file = new File(s);
            if (!file.isFile()){
                file.createNewFile();
            }
            FileOutputStream fos = new FileOutputStream(file,true);//追加写入加上true


            byte[] bytes = content.getBytes();
            fos.write(bytes,0,bytes.length);
            fos.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Boolean write(String content){
        String s = new String("D:\\log.txt");
        try {
            File file = new File(s);
            if (!file.isFile()){
                file.createNewFile();
            }
            FileOutputStream fos = new FileOutputStream(file,true);//追加写入加上true
            byte[] bytes = content.getBytes();
            fos.write(bytes,0,bytes.length);
            fos.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String read(String s){
        try {
            File file = new File(s);
            if (!file.isFile()){
                file.createNewFile();
            }
            FileInputStream foi = new FileInputStream(file);
            byte[] bytes = new byte[1024];
            int len ;
            StringBuffer input=new StringBuffer();
            while ((len=foi.read(bytes))!=-1){
                input.append(new String(bytes,0,len));
            }
            foi.close();
            return new String(input);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String read(){
        String s = new String("D:\\log.txt");
        try {
            File file = new File(s);
            if (!file.isFile()){
                file.createNewFile();
            }
            FileInputStream foi = new FileInputStream(file);
            byte[] bytes = new byte[1024];
            int len ;
            StringBuffer input=new StringBuffer();
            while ((len=foi.read(bytes))!=-1){
                input.append(new String(bytes,0,len));
            }
            foi.close();
            return new String(input);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
