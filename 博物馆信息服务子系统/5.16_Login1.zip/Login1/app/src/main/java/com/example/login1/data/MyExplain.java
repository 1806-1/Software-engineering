package com.example.login1.data;

import java.util.List;

public class MyExplain {


    private int number;
    private List<ExplanationsDTO> explanations;

    public int getNumber() {
        return number;
    }
    public void setNumber(int number) {
        this.number = number;
    }

    public List<ExplanationsDTO> getExplanations() {
        return explanations;
    }
    public void setExplanations(List<ExplanationsDTO> explanations) {
        this.explanations = explanations;
    }

    public static class ExplanationsDTO {

        private String id;
        private String type;
        private String objectid;
        private String objectname;
        private String introduction;

        public String getId() {
            return id;
        }
        public void setId(String id) {
            this.id = id;
        }

        public String getType() {
            return type;
        }
        public void setType(String type) {
            this.type = type;
        }

        public String getObjectid() {
            return objectid;
        }
        public void setObjectid(String objectid) {
            this.objectid = objectid;
        }

        public String getObjectname() {
            return objectname;
        }
        public void setObjectname(String objectname) {
            this.objectname = objectname;
        }

        public String getIntroduction() {
            return introduction;
        }
        public void setIntroduction(String introduction) {
            this.introduction = introduction;
        }
    }
}
