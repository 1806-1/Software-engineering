package com.wenr.model;

public class Teacher {

public int louhao;
public int qinshi;
public long bianhao;
public String time;
public String type;
public int jine;
public String jiaofei;
public String unknow;
public int getLouhao() {
	return louhao;
}
public void setLouhao(int louhao) {
	this.louhao = louhao;
}
public int getQinshi() {
	return qinshi;
}
public void setQinshi(int qinshi) {
	this.qinshi = qinshi;
}
public long getBianhao() {
	return bianhao;
}
public void setBianhao(long bianhao) {
	this.bianhao = bianhao;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public int getJine() {
	return jine;
}
public void setJine(int jine) {
	this.jine = jine;
}
public String getJiaofei() {
	return jiaofei;
}
public void setJiaofei(String jiaofei) {
	this.jiaofei = jiaofei;
}
public String getUnknow() {
	return unknow;
}
public void setUnknow(String unknow) {
	this.unknow = unknow;
}
 
 

}
