package com.wenr.model;

public class Student {
	private Integer sid;
	private String spwd;
	private String sname;;
	private String sex;
	private String nation;
	private String zhuanye;
	private String classn;
	private String lianxi;
	private Integer louhao;
	private Integer qinshi;
	private String unknow1;
	private String unknow2;
	public Integer getSid() {
		return sid;
	}
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	public String getSpwd() {
		return spwd;
	}
	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getZhuanye() {
		return zhuanye;
	}
	public void setZhuanye(String zhuanye) {
		this.zhuanye = zhuanye;
	}
	public String getClassn() {
		return classn;
	}
	public void setClassn(String classn) {
		this.classn = classn;
	}
	public String getLianxi() {
		return lianxi;
	}
	public void setLianxi(String lianxi) {
		this.lianxi = lianxi;
	}
	public Integer getLouhao() {
		return louhao;
	}
	public void setLouhao(Integer louhao) {
		this.louhao = louhao;
	}
	public Integer getQinshi() {
		return qinshi;
	}
	public void setQinshi(Integer qinshi) {
		this.qinshi = qinshi;
	}
	public String getUnknow1() {
		return unknow1;
	}
	public void setUnknow1(String unknow1) {
		this.unknow1 = unknow1;
	}
	public String getUnknow2() {
		return unknow2;
	}
	public void setUnknow2(String unknow2) {
		this.unknow2 = unknow2;
	}
	
	

}
