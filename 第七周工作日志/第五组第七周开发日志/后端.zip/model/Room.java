package com.wenr.model;

public class Room {

public int qinshi;
public int louhao;
public int renshu;
public String phone;
public int remainren;
public int fee;
public String unknow;
public int getQinshi() {
	return qinshi;
}
public void setQinshi(int qinshi) {
	this.qinshi = qinshi;
}
public int getLouhao() {
	return louhao;
}
public void setLouhao(int louhao) {
	this.louhao = louhao;
}
public int getRenshu() {
	return renshu;
}
public void setRenshu(int renshu) {
	this.renshu = renshu;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public int getRemainren() {
	return remainren;
}
public void setRemainren(int remainren) {
	this.remainren = remainren;
}
public int getFee() {
	return fee;
}
public void setFee(int fee) {
	this.fee = fee;
}
public String getUnknow() {
	return unknow;
}
public void setUnknow(String unknow) {
	this.unknow = unknow;
}



}
