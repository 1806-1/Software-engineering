package com.wenr.dao;

import com.wenr.*;
import com.wenr.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @author wenr 1024
 * @create 2021-04-23 14:59
 */
public class UserDao {
    //通过用户名,筛选用户信息,用户名不唯一,会筛选出很多
     public ArrayList<User> selectUserByName(String name) {
        ArrayList<User> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtil.getUserConnection();
            String sql = "select id, email, phone, name, password, status, regtime, root from user where name = ?";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getLong("id"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setName(rs.getString("name"));
                user.setPassword(rs.getString("password"));
                user.setStatus(rs.getLong("status"));
                user.setRegtime(rs.getDate("regtime"));
                user.setRoot(rs.getLong("root"));
                list.add(user);
            } else
                return null;
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return list;
    }
}
