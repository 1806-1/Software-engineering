
import dao.UserDao;
import dao.WriterDao;
import dao.dataDao;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;




public class UserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

           if (method.equals("delete")){
               int id= Integer.parseInt(request.getParameter("id"));
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               UserDao userDao = new UserDao();
               if (userDao.deleteUserByID(id)) {
                   out.print("yes");
               } else
                   out.print("no");
           }
           else if (method.equals("update")){
                UserDao userDao = new UserDao();
                String rootname = request.getParameter("rootname");
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (userDao.updateUser(create(request))) {
                   out.println("yes");
               } else
                   out.println("no");
        	   
            }
           
           else if ("add".equals(method)) {
               UserDao userDao = new UserDao();
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (userDao.addUser(create2(request))) {
                   out.println("yes");
               } else
                   out.println("no");
              // System.out.println(request.getParameter("nn"));

           }
           else if ("look".equals(method)){
              
               ArrayList<User> list = new ArrayList();
               UserDao userDao = new UserDao();
               User user=userDao.getUserByName(request.getParameter("name"));
               list.add(user);
               getOne(out,list);
            }
            else if ("lookkkk9".equals(method)){
                System.out.println("3333333333hhhhhhhhhh");
                ArrayList<User> list = new ArrayList();
                UserDao userDao = new UserDao();
                list=userDao.isClassic9();
                getOne(out,list);
             }
            else if ("lookkkk10".equals(method)){
                System.out.println("3333333333hhhhhhhhhh");
                ArrayList<User> list = new ArrayList();
                UserDao userDao = new UserDao();
                list=userDao.isClassic10();
                getOne(out,list);
             }
            else if ("restore".equals(method)) {
         	   dataDao dataDao = new dataDao();
         	   String data = request.getParameter("date");
         	   String table = request.getParameter("from");
         	   String rootname = request.getParameter("rootname");
         	   Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
         	   WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"恢复\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
         	   if (dataDao.recover(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               

            }
            else if ("backup".equals(method)) {
         	   dataDao dataDao = new dataDao();
         	   String data = request.getParameter("date");
         	   String table = request.getParameter("from");
         	   String rootname = request.getParameter("rootname");
         	   Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
         	   WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"备份\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
                if (dataDao.backup(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               

            }
        }
        else{
            getALL(out);
        }
    }
    public void getALL(PrintWriter out){
        UserDao userDao = new UserDao();
        ArrayList<User> list = userDao.getAllUser();
        getOne(out,list);
    }

    public void getOne(PrintWriter out,ArrayList<User> list){

        int size =list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");


        for (int i = 0; i < size; i++) {
            buffer.append("{\"id\":"+list.get(i).getId()+",");

            String email = list.get(i).getEmail().replace("\"", " ").trim();
            email=email.replace("\\", " ").trim();
            email=email.replace("@", " ").trim();
            
            buffer.append("\"email\": \""+email+"\",");

            String phone = list.get(i).getPhone().replace("\"", " ").trim();
            phone=phone.replace("\\", " ").trim();
            phone=phone.replace("\n", " ").trim();
            buffer.append("\"phone\": \""+phone+"\",");

            String name = list.get(i).getName().replace("\"", " ").trim();
            name=name.replace("\\", " ").trim();
            name=name.replace("\n", " ").trim();
            buffer.append("\"name\": \""+name+"\",");

            String password = list.get(i).getPassword().replace("\"", " ").trim();
            password=password.replace("\\", " ").trim();
            password=password.replace("\n", " ").trim();
            buffer.append("\"password\": \""+password+"\",");

            buffer.append("\"status\":"+list.get(i).getStatus()+",");

            buffer.append("\"regtime\":\""+simple.format(list.get(i).getRegtime())+"\",");
            buffer.append("\"root\":"+list.get(i).getRoot()+"}");

            if (i!=size-1)
                buffer.append(",");
        }
        buffer.append("]}");
        String s1 = new String(buffer);
        out.print(s1);
    }

    public User create(HttpServletRequest request) {
        User user = new User();
        user.setId(Integer.parseInt(request.getParameter("id")));
        user.setEmail(request.getParameter("email"));
        user.setPhone(request.getParameter("phone"));
        user.setName(request.getParameter("name"));
        user.setPassword(request.getParameter("password"));
        user.setStatus(Integer.parseInt(request.getParameter("status")));
        user.setRegtime(Date.valueOf(request.getParameter("regtime")));
        user.setRoot(Integer.parseInt(request.getParameter("root")));
        return user;
    }

    public User create2(HttpServletRequest request) {
        User user = new User();
        user.setEmail(request.getParameter("email"));
        user.setPhone(request.getParameter("phone"));
        user.setName(request.getParameter("name"));
        user.setPassword(request.getParameter("password"));
        int a=-1;
        if(Integer.parseInt(request.getParameter("status"))>a)
            user.setStatus(Integer.parseInt(request.getParameter("status")));
        else
        	user.setStatus(1);
        Date date =  new Date(System.currentTimeMillis());
        user.setRegtime(date);
        user.setRoot(Integer.parseInt(request.getParameter("root")));
        return user;
    }






}
