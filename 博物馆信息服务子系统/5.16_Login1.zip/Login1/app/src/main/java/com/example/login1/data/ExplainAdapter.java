package com.example.login1.data;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login1.R;

import java.util.List;

public class ExplainAdapter extends RecyclerView.Adapter<ExplainAdapter.MyViewHolder> {

    private List<MyExplain.ExplanationsDTO> explanationsDTOList;

    //构造函数
    public ExplainAdapter(List<MyExplain.ExplanationsDTO> explanationsDTOList) {
        this.explanationsDTOList = explanationsDTOList;
    }

    @NonNull
    @Override
    public ExplainAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_explain_recycler, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ExplainAdapter.MyViewHolder holder, int position) {
        MyExplain.ExplanationsDTO explanationsDTO = explanationsDTOList.get(position);
        holder.typeText.setText(explanationsDTO.getType());
        holder.introductionText.setText(explanationsDTO.getIntroduction());
        holder.objectnameText.setText(explanationsDTO.getObjectname());
    }

    @Override
    public int getItemCount() {
        return explanationsDTOList.size();
    }

    //装控件的类
    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView typeText;
        TextView introductionText;
        TextView objectnameText;

        //itemView是item的view对象……
        public MyViewHolder(View itemView) {
            super(itemView);
            this.typeText = itemView.findViewById(R.id.textView_type);
            this.introductionText = itemView.findViewById(R.id.textView_introduction);
            this.objectnameText = itemView.findViewById(R.id.textView_objectname);
        }

    }
}
