
import dao.ExplainDao;
import model.Explain;
import dao.WriterDao;
import dao.dataDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


@WebServlet(name="ExplainServlet",
        urlPatterns={"/WebApp/ExplainServlet"}
       )

public class ExplainServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

           if (method.equals("delete")){
               int id= Integer.parseInt(request.getParameter("id"));
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               ExplainDao explainDao = new ExplainDao();             
               if (explainDao.deleteExplain(id)) {
                   out.print("yes");
               } else
                   out.print("no");
           }
           else if (method.equals("update")){
               ExplainDao explainDao = new ExplainDao();
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (explainDao.updateExplain(create(request))) {
                   out.println("yes");
               } else
                   out.println("no");
            }
           

            else if ("look".equals(method)){
                ArrayList<Explain> list = new ArrayList();
                ExplainDao explainDao = new ExplainDao();
                list=explainDao.getExplainByName(request.getParameter("museum"));
                getOne(out,list);
             }
            else if ("add".equals(method)) {
                ExplainDao explainDao = new ExplainDao();
                String rootname = request.getParameter("rootname");
                WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                if (explainDao.addExplain(create2(request))) {
                    out.println("yes");
                } else
                    out.println("no");
                System.out.println(request.getParameter("nn"));
 
            }
            else if ("lookkkk".equals(method)){
                System.out.println("3333333333hhhhhhhhhh");
                ArrayList<Explain> list = new ArrayList();
                ExplainDao explainDao = new ExplainDao();
                list=explainDao.getExplainByName("中国国家博物馆");
                getOne(out,list);
             }
            else if ("restore".equals(method)) {
         	   dataDao dataDao = new dataDao();
         	   String data = request.getParameter("date");
         	   String table = request.getParameter("from");
         	   String rootname = request.getParameter("rootname");
         	   Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
         	   WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"恢复\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
         	   if (dataDao.recover(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               

            }
            else if ("backup".equals(method)) {
         	   dataDao dataDao = new dataDao();
         	   String data = request.getParameter("date");
         	   String table = request.getParameter("from");
         	   String rootname = request.getParameter("rootname");
         	   Date date =  new Date(System.currentTimeMillis());
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
         	   WriterDao writerDao = new WriterDao();
                writerDao.write(",{\"管理员\":\""+rootname+"\",");
                writerDao.write("\"操作\":\"备份\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
                if (dataDao.backup(data,table)) {
                    out.println("yes");
                } else
                    out.println("no");
               

            }
 
         }
         else{
             getALL(out);
         }
     }
     public void getALL(PrintWriter out){
        ExplainDao explainDao = new ExplainDao();
        ArrayList<Explain> list = explainDao.getAllExplain();
        getOne(out,list);
    }

    public void getOne(PrintWriter out,ArrayList<Explain> list){

        int size = list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");


        for (int i = 0; i < size; i++) {
            buffer.append("{\"id\":"+list.get(i).getId()+",");
            buffer.append("\"type\":"+list.get(i).getType()+",");
            buffer.append("\"museumID\":"+list.get(i).getMuseumID()+",");
            buffer.append("\"exhibitionID\":"+list.get(i).getExhibitionID()+",");
            buffer.append("\"collectionID\":"+list.get(i).getCollectionID()+",");
            String name = list.get(i).getName().replace("\""," ");
            name = name.replace("\n","");
            buffer.append("\"name\": \""+name+"\",");
            buffer.append("\"userID\":"+list.get(i).getUserID()+",");
            
            String intee = list.get(i).getIntroduction();
            intee=intee.replace("\n","");
            intee=intee.replace("\""," ");
            buffer.append("\"introduction\":\""+intee+"\",");
            
            String replace = list.get(i).getAudio().replace("\"", " ");
            replace = replace.replace("\n", "");
            replace = replace.replace("\"", " ");
            buffer.append("\"audio\":\""+replace+"\",");
            
            
            buffer.append("\"status\":"+list.get(i).getStatus()+"}");
            
            if (i!=size-1)
                buffer.append(",");
        }
        buffer.append("]}");
        String s1 = new String(buffer);
        
        out.print(s1);


    }

    public void getone(PrintWriter out,ArrayList<Explain> list){

        int size = list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");


        for (int i = 0; i < size; i++) {
            buffer.append("{\"id\":"+list.get(i).getId()+",");
            buffer.append("{\"type\":"+list.get(i).getType()+",");
            buffer.append("{\"museumID\":"+list.get(i).getMuseumID()+",");
            buffer.append("{\"exhibitionid\":"+list.get(i).getExhibitionID()+",");
            buffer.append("{\"collectionid\":"+list.get(i).getCollectionID()+",");
            String intee = list.get(i).getName();
            intee=intee.replace("\n","");
            buffer.append("\"name\":\""+intee+"\",");

            buffer.append("\"userID\":\""+simple.format(list.get(i).getUserID())+"\",");
            intee = list.get(i).getIntroduction();
            intee=intee.replace("\n","");
            buffer.append("\"introduction\":\""+intee+"\",");
            intee = list.get(i).getAudio();
            intee=intee.replace("\n","");
            buffer.append("\"audio\":\""+intee+"\",");
            buffer.append("\"status\":\""+list.get(i).getStatus()+"\"}");
            
            if (i!=size-1)
                buffer.append(",");
        }
        buffer.append("]}");
        String s1 = new String(buffer);
        out.print(s1);


    }

    public Explain create(HttpServletRequest request) {
        Explain explain = new Explain();
        explain.setId(Integer.parseInt(request.getParameter("id")));
        explain.setType(Integer.parseInt(request.getParameter("type")));
        explain.setMuseumID(Integer.parseInt(request.getParameter("museumID")));
        explain.setExhibitionID(Integer.parseInt(request.getParameter("exhinitionID")));
        explain.setCollectionID(Integer.parseInt(request.getParameter("collectionID")));
        explain.setName(request.getParameter("name"));
        explain.setUserID(Integer.parseInt(request.getParameter("userID")));
        explain.setIntroduction(request.getParameter("introduction"));
        explain.setAudio(request.getParameter("audio"));
        explain.setStatus(Integer.parseInt(request.getParameter("status")));
        return explain;
    }
    public Explain create2(HttpServletRequest request) {
        Explain explain = new Explain();
        explain.setType(Integer.parseInt(request.getParameter("type")));
        explain.setMuseumID(Integer.parseInt(request.getParameter("museumID")));
        explain.setExhibitionID(Integer.parseInt(request.getParameter("exhinitionID")));
        explain.setCollectionID(Integer.parseInt(request.getParameter("collectionID")));
        explain.setName(request.getParameter("name"));
        explain.setUserID(Integer.parseInt(request.getParameter("userID")));
        explain.setIntroduction(request.getParameter("introduction"));
        explain.setAudio(request.getParameter("audio"));
        explain.setStatus(Integer.parseInt(request.getParameter("status")));
        return explain;
    }






}
