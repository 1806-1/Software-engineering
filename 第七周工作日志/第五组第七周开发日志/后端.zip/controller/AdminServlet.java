package com.wenr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wenr.dao.BuildDao;

import com.wenr.dao.RoomDao;
import com.wenr.dao.StudentDao;
import com.wenr.model.Build;

import com.wenr.model.Room;
import com.wenr.model.Student;

public class AdminServlet extends HttpServlet {

	public AdminServlet() {
		super();
	}

	public void destroy() {
		super.destroy();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");

		String action = request.getParameter("action");
		String path = request.getContextPath();
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();

		if ("studentdelete".equals(action)) {
			StudentDao studentDao = new StudentDao();
			if (studentDao.deleteStudent(Integer.parseInt(request
					.getParameter("sid"))))
				out.println("<h1>ɾ���ɹ���</h1>");
			else
				out.println("<h1>ɾ��ʧ�ܣ���ѧ���������ҵ��·ѻ�δ�Ͻ�</h1>");
			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchStudent.jsp\">����</a>");

		} else if ("roomdelete".equals(action)) {
			RoomDao RoomDao = new RoomDao();

			if (RoomDao.deleteRoom(
					Integer.parseInt(request.getParameter("qinshi")),
					Integer.parseInt(request.getParameter("louhao"))))
				out.println("<h1>ɾ���ɹ���</h1>");
			else
				out.println("<h1>ɾ��ʧ��!��鿴�����������Ƿ�����ѧ����ס</h1>");
			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchRoom.jsp\">����</a>");

		} else if ("builddelete".equals(action)) {
			BuildDao BuildDao = new BuildDao();
			BuildDao.deleteBuild(
					Integer.parseInt(request.getParameter("louhao")),
					Integer.parseInt(request.getParameter("louceng")));
			response.sendRedirect("../adminSearchBuild.jsp");

		} else if ("lookup".equals(action)) {
			int studentsid = 0;
			if (request.getParameter("sid") != null) {
				studentsid = Integer.parseInt(request.getParameter("sid"));

				ArrayList<Student> list = new ArrayList<>();
				StudentDao dao = new StudentDao();
				list = dao.getStudentBysid(studentsid);
				if (list != null) {

					request.setAttribute("studentList", list);

					request.getRequestDispatcher("../adminSearchStudent2.jsp")
							.forward(request, response);
				} else
					out.println("<h1>��ѯʧ�ܣ�����ѧ�Ų�����</h1>");
			}
			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchStudent.jsp\">����</a>");

		} else if ("roomlookup".equals(action)) {
			int room1 = 0;
			int room2 = 0;
			if (request.getParameter("qinshi") != null
					&& request.getParameter("louhao") != null) {
				room1 = Integer.parseInt(request.getParameter("qinshi"));
				room2 = Integer.parseInt(request.getParameter("louhao"));

				ArrayList<Room> list = new ArrayList<>();
				RoomDao dao = new RoomDao();

				list = dao.getRoomby(room1, room2);
				if (list != null) {
					request.setAttribute("roomList", list);
					request.getRequestDispatcher("../adminSearchRoom2.jsp")
							.forward(request, response);
				} else
					out.println("<h1>��ѯʧ�ܣ������Ӧ�����Ҳ�����</h1>");
				out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchRoom.jsp\">����</a>");

			}
		} else if ("buildlookup".equals(action)) {
			int a = 0;
			int b = 0;
			if (request.getParameter("louceng") != null
					&& request.getParameter("louhao") != null) {
				a = Integer.parseInt(request.getParameter("louhao"));
				b = Integer.parseInt(request.getParameter("louceng"));
				ArrayList<Build> list = new ArrayList<>();
				BuildDao dao = new BuildDao();

				list = dao.getBuildby(a, b);
				if (list != null) {

					request.setAttribute("buildList", list);
					request.getRequestDispatcher("../adminSearchBuild2.jsp")
							.forward(request, response);
				} else {
					out.println("<h1>��ѯʧ�ܣ������Ӧ�Ĺ�Ԣ��Ϣ������</h1>");
					out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchBuild.jsp\">����</a>");

				}
			}

		} else if ("updatestudent".equals(action)) {

			Student student = new Student();
			StudentDao studentDao = new StudentDao();

			student.setSid(Integer.parseInt(request.getParameter("sid")));
			student.setSname(request.getParameter("sname"));

			student.setZhuanye(request.getParameter("zhuanye"));
			student.setClassn(request.getParameter("classn"));
			student.setLianxi(request.getParameter("lianxi"));
			student.setLouhao(Integer.parseInt(request.getParameter("louhao")));
			student.setQinshi(Integer.parseInt(request.getParameter("qinshi")));
			if (studentDao.updateStudent(student)) {
				out.println("<h1>�޸ĳɹ���</h1>");
			} else {
				out.println("<h1>�޸�ʧ�ܣ���鿴�����������Ƿ����޿�λ�������Ҳ�����</h1>");
			}
			;
			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchStudent.jsp\">����</a>");

		} else if ("updateroom".equals(action)) {

			Room room = new Room();
			RoomDao roomDao = new RoomDao();

			room.setQinshi(Integer.parseInt(request.getParameter("qinshi")));
			room.setLouhao(Integer.parseInt(request.getParameter("louhao")));
			room.setRenshu(Integer.parseInt(request.getParameter("renshu")));
			room.setPhone(request.getParameter("phone"));

			room.setFee(Integer.parseInt(request.getParameter("fee")));

			roomDao.updateRoom(room);
			response.sendRedirect("../adminSearchRoom.jsp");
		} else if ("updatebuild".equals(action)) {

			Build build = new Build();
			BuildDao buildDao = new BuildDao();

			build.setLouceng(Integer.parseInt(request.getParameter("louceng")));
			build.setLouhao(Integer.parseInt(request.getParameter("louhao")));
			build.setFangjian(Integer.parseInt(request.getParameter("fangjian")));
			build.setAlllouceng(Integer.parseInt(request
					.getParameter("alllouceng")));

			build.setTime(request.getParameter("time"));

			buildDao.updateBuild(build);
			response.sendRedirect("../adminSearchBuild.jsp");
		} else if ("updatefang".equals(action)) {

			BuildDao buildDao = new BuildDao();

			if (buildDao.updatefang(Integer.parseInt(request
					.getParameter("louhao"))))
				out.println("<h1>���³ɹ���</h1>");

			else

				out.println("<h1>����ʧ�ܣ�</h1>");

			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchBuild.jsp\">����</a>");

		} else if ("addStudent".equals(action)) {

			Student student = new Student();
			StudentDao studentDao = new StudentDao();

			student.setSid(Integer.parseInt(request.getParameter("sid")));
			student.setSname(request.getParameter("sname"));
			student.setSex(request.getParameter("sex"));
			student.setNation(request.getParameter("nation"));
			student.setZhuanye(request.getParameter("zhuanye"));
			student.setClassn(request.getParameter("classn"));
			student.setLianxi(request.getParameter("lianxi"));
			student.setLouhao(Integer.parseInt(request.getParameter("louhao")));
			student.setQinshi(Integer.parseInt(request.getParameter("qinshi")));
			if (studentDao.addStudent(student)) {

				out.println("<h1>���ӳɹ���</h1>");
			} else {
				out.println("<h1>����ʧ�ܣ���鿴ѧ�����������Ƿ����޿�λ�������Ҳ����ڻ���ѧ���Ƿ��Ѿ��ظ�</h1>");
			}
			;
			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchStudent.jsp\">����</a>");

		} else if ("addroom".equals(action)) {
			Room Room = new Room();
			RoomDao RoomDao = new RoomDao();

			Room.setQinshi(Integer.parseInt(request.getParameter("qinshi")));
			Room.setLouhao(Integer.parseInt(request.getParameter("louhao")));
			Room.setRenshu(Integer.parseInt(request.getParameter("renshu")));
			Room.setPhone(request.getParameter("phone"));
			Room.setRemainren(Integer.parseInt(request.getParameter("renshu")));
			Room.setFee(Integer.parseInt(request.getParameter("fee")));

			if (RoomDao.addRoom(Room)) {
				out.println("<h1>���ӳɹ���</h1>");
			} else
				out.println("<h1>����ʧ�ܣ���鿴���ӵ����Һ��Ƿ���Ϲ淶���Ƿ����</h1>");
			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchRoom.jsp\">����</a>");

		}

		else if ("addbuild".equals(action)) {
			BuildDao buildDao = new BuildDao();
			Build build = new Build();
			build.setLouhao(Integer.parseInt(request.getParameter("louhao")));
			build.setLouceng(Integer.parseInt(request.getParameter("louceng")));
			build.setFangjian(Integer.parseInt(request.getParameter("fangjian")));
			build.setAlllouceng(Integer.parseInt(request
					.getParameter("alllouceng")));
			build.setRemainfang(Integer.parseInt(request
					.getParameter("remainfang")));
			build.setTime(request.getParameter("time"));
			if (buildDao.addBuild(build))
				out.println("<h1>���ӳɹ���</h1>");
			else
				out.println("<h1>����ʧ�ܣ���鿴���ӵĹ�Ԣ��Ϣ�Ƿ�Ϸ�</h1>");
			out.println("<a href=\"http://localhost:8080/StudentAchievementManagementSystem-master/adminSearchBuild.jsp\">����</a>");

		}

	}

	public void init() throws ServletException {

	}

}
