$(function(){
    var scrollIndex = 0;
    var scrollIndex1 = 1;
    var scrollIndex2 = 2;
    var scrollIndex3 = 3;
    var scrolltimer = null;
    var scrollimgs = $(".scroll-table-body-inner>ul");
	var scrolltime = 1500;
	var scrollplayNum = scrollimgs.length - 1;
	function  moveTop() {
		scrollimgs.eq(scrollIndex).stop(true).animate({top: '-33%'},function(){
            $(this).css({top:"100%"});
		});
		scrollimgs.eq(scrollIndex1).stop(true).animate({top: 0});
		scrollimgs.eq(scrollIndex2).stop(true).animate({top: '33%'});
		scrollimgs.eq(scrollIndex3).stop(true).animate({top: '66%'});
		scrollimgs.removeClass();
   }
	function autoPlay() {
        if(scrollIndex > scrollplayNum) {
            scrollIndex = 0;
        }
        if(scrollIndex1 > scrollplayNum) {
            scrollIndex1 = 0;
        }
        if(scrollIndex2 > scrollplayNum) {
            scrollIndex2 = 0;
        }
        if(scrollIndex3 > scrollplayNum) {
            scrollIndex3 = 0;
        }
        moveTop();
        scrollIndex++;
        scrollIndex1++;
        scrollIndex2++;
        scrollIndex3++;
    }
	scrolltimer = setInterval(autoPlay,scrolltime);
	$(".scroll-table-body").mouseenter(function () {
        clearInterval(scrolltimer);
    }).mouseleave(function () {
        scrolltimer = setInterval(autoPlay,scrolltime);
    });
});
