package model;


import java.sql.Date;

public class Activity {
    private int id;
    private String actname;
    private String museumName;
    private Date time;
    private String introduction;
    private String photo;

    @Override
    public String toString() {
        return "Activity{" +
                "id=" + id +
                ", actname='" + actname + '\'' +
                ", museumName='" + museumName + '\'' +
                ", time=" + time +
                ", introduction='" + introduction + '\'' +
                ", photo='" + photo + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getActname() {
        return actname;
    }

    public void setActname(String actname) {
        this.actname = actname;
    }

    public String getMuseumName() {
        return museumName;
    }

    public void setMuseumName(String museumName) {
        this.museumName = museumName;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
