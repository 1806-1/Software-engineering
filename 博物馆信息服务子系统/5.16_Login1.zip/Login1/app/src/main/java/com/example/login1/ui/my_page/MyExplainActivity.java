package com.example.login1.ui.my_page;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.example.login1.R;
import com.example.login1.data.ExplainAdapter;
import com.example.login1.data.MyExplain;
import com.example.login1.data.MyInformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MyExplainActivity extends AppCompatActivity {

    private static final String BASEURL = "http://10.12.84.155/MyExplain";
    private androidx.appcompat.widget.Toolbar toolbar;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_explain);

        toolbar = findViewById(R.id.toolbar_my_explain);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recycler_explain);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        //get方式 userid参数 请求讲解
        String userid = MyInformation.getId();
        String url = BASEURL + "?userid=" + userid;

        //子线程网络请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL urls = new URL(url);
                    HttpURLConnection httpURLConnection = null;
                    BufferedReader bufferedReader = null;

                    httpURLConnection = (HttpURLConnection) urls.openConnection();
                    httpURLConnection.setRequestMethod("GET");  //设置请求方法为get
                    httpURLConnection.setConnectTimeout(5000);  //连接超时
                    httpURLConnection.setReadTimeout(5000);

                    InputStream in = httpURLConnection.getInputStream();
                    bufferedReader = new BufferedReader(new InputStreamReader(in));

                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        result.append(line);
                    }

                    String returnExplain = result.toString();
                    Log.i("返回的讲解json", returnExplain);

                    List<MyExplain.ExplanationsDTO> theExplain = new ArrayList<>();
                    explainJsonParse(returnExplain, theExplain);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ExplainAdapter explainAdapter = new ExplainAdapter(theExplain);
                            recyclerView.setLayoutManager(layoutManager);
                            recyclerView.setAdapter(explainAdapter);
                        }
                    });


                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }

            }
        }).start();


    }

    //解析封装讲解json
    private void explainJsonParse(String returnExplain, List<MyExplain.ExplanationsDTO> theExplain) throws JSONException {

        MyExplain explain = new MyExplain();
        JSONObject jsonObject = new JSONObject(returnExplain);

        //第一层解析
        int number = jsonObject.optInt("number");
        //explains：json数组[{},{},...,{}]
        JSONArray explains = jsonObject.optJSONArray("explanations");

        //第一层封装
        explain.setNumber(number);
        explain.setExplanations(theExplain);

        //第二层解析
        for (int i = 0; i < number; i++) {
            assert explains != null;
            JSONObject jsonObject1 = explains.optJSONObject(i);

            String id = jsonObject1.optString("id");
            String type = jsonObject1.optString("type");
            String objectid = jsonObject1.optString("objectid");
            String objectname = jsonObject1.optString("objectname");
            String introduction = jsonObject1.optString("introduction");

            MyExplain.ExplanationsDTO explanationsDTO = new MyExplain.ExplanationsDTO();
            explanationsDTO.setId(id);
            explanationsDTO.setIntroduction(introduction);
            explanationsDTO.setObjectid(objectid);
            explanationsDTO.setObjectname(objectname);
            explanationsDTO.setType(type);
            theExplain.add(explanationsDTO);

//            Log.i("第" + i + "个讲解", theExplain.get(i).toString());   //打印出是地址，好像不对
        }
    }
}