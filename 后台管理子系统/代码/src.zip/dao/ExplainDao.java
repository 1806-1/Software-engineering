package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import model.Comment;
import model.Explain;
import util.DBUtil2;

public class ExplainDao {
//    public static void main(String[] args) {
//        ExplainDao explainDao = new ExplainDao();
//        int[] explainTypeI = explainDao.getExplainTypeI(1);
//        //System.out.println(explainTypeI);
//        System.out.println(explainDao.getExplainTypeS(explainTypeI[0]));
//    }


    public  void close(PreparedStatement pstmt, Connection conn) {

        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public  void close(ResultSet rs,PreparedStatement pstmt, Connection conn ) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        close(pstmt,conn);
    }

    public ArrayList<Explain> getAllExplain() {

        ArrayList<Explain> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from `explain`";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getExp(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }
    
    public Explain getExplainById(int id) {

        Explain explain = new Explain();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from `explain` where id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,id);
            rs = pstmt.executeQuery();
            if (rs != null && rs.next()) {
                explain=getExp(rs);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return explain;
        }


    }


    public boolean addExplain(Explain explain) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();

                String sql = "insert into `explain`(type,museumID,exhibitionID,collectionID,name,userID,introduction,audio,status) values(?,?,?,?,?,?,?,?,?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, explain.getType());
                pstmt.setInt(2, explain.getMuseumID());
                pstmt.setInt(3, explain.getExhibitionID());
                pstmt.setInt(4, explain.getCollectionID());
                pstmt.setString(5, explain.getName());
                pstmt.setInt(6, explain.getUserID());
                pstmt.setString(7, explain.getIntroduction());
                pstmt.setString(8, explain.getAudio());
                pstmt.setInt(9, explain.getStatus());
                pstmt.executeUpdate();
                close(pstmt,conn);
                WriterDao writerDao = new WriterDao();
                Date date = new Date();
                SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String format = simple.format(date.getTime());
                String replace = explain.toString().replace("\\", " ");
                replace = replace.replace("\n", " ");
                writerDao.write("\"操作\":\"增加\",\"操作时间\":\""+
                        format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
                return true;
        } catch (SQLException ex) {
            return false;
        }

    }

    public boolean updateExplain(Explain explain) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "update `explain` set type=?,museumID=?,exhibitionID=?,collectionID=?,name=?,userID=?,introduction=?,audio=?,status=? where id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, explain.getType());
            pstmt.setInt(2, explain.getMuseumID());
            pstmt.setInt(3, explain.getExhibitionID());
            pstmt.setInt(4, explain.getCollectionID());
            pstmt.setString(5, explain.getName());
            pstmt.setInt(6, explain.getUserID());
            pstmt.setString(7, explain.getIntroduction());
            pstmt.setString(8, explain.getAudio());
            pstmt.setInt(9, explain.getStatus());
            pstmt.setInt(10,explain.getId());
            pstmt.executeUpdate();
            close(pstmt,conn);
            WriterDao writerDao = new WriterDao();
            Date date = new Date();
            SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = simple.format(date.getTime());
            String replace = explain.toString().replace("\\", " ");
            replace = replace.replace("\n", " ");
            writerDao.write("\"操作\":\"修改\",\"操作时间\":\""+
                    format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
            return  true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }

    }

    public boolean deleteExplain(int id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        Explain explainById = getExplainById(id);
        WriterDao writerDao = new WriterDao();
        Date date = new Date();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String format = simple.format(date.getTime());
        String replace = explainById.toString().replace("\\", " ");
        replace = replace.replace("\n", " ");
        writerDao.write("\"操作\":\"删除\",\"操作时间\":\""+
                format+"\",\"操作内容\":\""+replace.replace("\"","")+"\"}");
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "delete from `explain` where id=? ";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            close(pstmt,conn);
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }

    }

    public int[] getExplainTypeI(int id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int[] ints = new int[2];
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select type,userID from `explain` where id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            rs.next();
            ints[0]=rs.getInt(1);
            ints[1]=rs.getInt(2);
            close(rs,pstmt,conn);
            return ints;


        } catch (SQLException ex) {
            ex.printStackTrace();
            return ints;
        }



    }

    public String getExplainTypeS(int aa) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql2=null;
        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            if(aa==1){
                sql2="select bwgname from overview where id in (select museumID from `explain` where id=?)";
            }
            else  if (aa==2){
                sql2="select exhname from exhibition where id in (select exhibitionID from `explain` where id=?)";
            }
            else if (aa==3){
                sql2="select colname from collection where id in (select collectionID from `explain` where id=?)";
            }
            pstmt = conn.prepareStatement(sql2);
            pstmt.setInt(1, aa);
            rs = pstmt.executeQuery();
            rs.next();
            close(rs,pstmt,conn);
            return rs.getString(1);


        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }


    }

    public ArrayList<Explain> getExplainByUserId(int aa) {

        ArrayList<Explain> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
			conn = dbUtil2.getConnection();
            String sql = "select * from `explain` where userID=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, aa);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getExp(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public ArrayList<Explain> getExplainByName(String name) {

        ArrayList<Explain> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from `explain` where name=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                list.add(getExp(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }


    }

    public Explain getExp(ResultSet rs) throws SQLException {
            Explain explain = new Explain();
            explain.setId(rs.getInt(1));
            explain.setType(rs.getInt(2));
            explain.setMuseumID(rs.getInt(3));
            explain.setExhibitionID(rs.getInt(4));
            explain.setCollectionID(rs.getInt(5));
            explain.setName(rs.getString(6));
            explain.setUserID(rs.getInt(7));
            explain.setIntroduction(rs.getString(8));
            explain.setAudio(rs.getString(9));
            explain.setStatus(rs.getInt(10));
            return explain;
    }

    public ArrayList<Explain> isApproved(int id) {
        ArrayList<Explain> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            DBUtil2 dbUtil2 = new DBUtil2();
            conn = dbUtil2.getConnection();
            String sql = "select * from `explain` where status=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,id);
            rs = pstmt.executeQuery();
            while (rs != null && rs.next()) {
                Explain exp = getExp(rs);
                list.add(exp);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            close(rs,pstmt,conn);
            return list;
        }
    }
}
