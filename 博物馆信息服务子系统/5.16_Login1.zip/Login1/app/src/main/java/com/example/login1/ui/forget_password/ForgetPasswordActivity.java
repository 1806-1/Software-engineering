package com.example.login1.ui.forget_password;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.example.login1.R;

public class ForgetPasswordActivity extends AppCompatActivity {

    //声明控件
    Button resetPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        //找到控件
        final EditText numberRegEditText=findViewById(R.id.numberRegister);
        final EditText resetEditText=findViewById(R.id.passwordRegister);
        final EditText veriCodeEditText=findViewById(R.id.verificationCode);
        resetPassword=findViewById(R.id.resettingPassword);
    }
    //没有验证码，是否还要实现重置密码？
}