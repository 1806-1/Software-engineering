package controller;
import dao.ActivityDao;
import dao.WriterDao;
import dao.dataDao;
import model.Activity;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;




public class ActivityServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String method = request.getParameter("method");
        PrintWriter out = response.getWriter();

        if(method!=null){

           if (method.equals("delete")){
               int id= Integer.parseInt(request.getParameter("id"));
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               ActivityDao activityDao = new ActivityDao();
               if (activityDao.deleteActivity(id)) {
                   out.print("yes");
               } else
                   out.print("no");
           }
           else if (method.equals("update")){
               ActivityDao activityDao = new ActivityDao();
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (activityDao.updateActivity(create(request))) {
                   out.println("yes");
               } else
                   out.println("no");
        	   
            }
           else if ("look".equals(method)){
               ArrayList<Activity> list = new ArrayList();
               ActivityDao activityDao = new ActivityDao();
               String museum = request.getParameter("museum");
               String actname = request.getParameter("actname");
               
               if (!museum.equals("")&&!actname.equals("")){
                   list=activityDao.getActivityByTwo(actname,museum);
                   
               }
               else if (museum.equals("")&&!actname.equals("")){

                   list=activityDao.getActivityByAN(actname);
                   
               }
               else if (!museum.equals("")&&actname.equals("")){
                   list=activityDao.getActivityByMN(museum);
                   
               }
               getOne(out,list);
           }
           else if ("add".equals(method)) {
               ActivityDao activityDao = new ActivityDao();
               String rootname = request.getParameter("rootname");
               WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               if (activityDao.addActivity(create2(request))) {
                   out.println("yes");
               } else
                   out.println("no");
              

           }
           else if ("restore".equals(method)) {
        	   dataDao dataDao = new dataDao();
        	   String data = request.getParameter("data");
        	   String table = request.getParameter("table");
        	   String rootname = request.getParameter("rootname");
        	   Date date =  new Date(System.currentTimeMillis());
               SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               String format = simple.format(date.getTime());
        	   WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               writerDao.write("\"操作\":\"恢复\",\"操作时间\":\""+
                       format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
        	   if (dataDao.recover(data,table)) {
                   out.println("yes");
               } else
                   out.println("no");
              

           }
           else if ("backup".equals(method)) {
        	   dataDao dataDao = new dataDao();
        	   String data = request.getParameter("data");
        	   String table = request.getParameter("table");
        	   String rootname = request.getParameter("rootname");
        	   Date date =  new Date(System.currentTimeMillis());
               SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               String format = simple.format(date.getTime());
        	   WriterDao writerDao = new WriterDao();
               writerDao.write(",{\"管理员\":\""+rootname+"\",");
               writerDao.write("\"操作\":\"备份\",\"操作时间\":\""+
                       format+"\",\"操作内容\":\""+data+"数据库"+table+"表\"}");
               if (dataDao.backup(data,table)) {
                   out.println("yes");
               } else
                   out.println("no");
              

           }
          


        }
        else{
            getALL(out);
        }
    }
    public void getALL(PrintWriter out){
        ActivityDao activityDao = new ActivityDao();
        ArrayList<Activity> list = activityDao.getAllActivity();
        getOne(out,list);
    }

    public void getOne(PrintWriter out,ArrayList<Activity> list){

        int size = list.size();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        StringBuffer buffer = new StringBuffer();
        buffer.append("{\"code\":0,\"msg\":\"\",\"count\":"+size+",\"data\":[");


        for (int i = 0; i < size; i++) {
            buffer.append("{\"id\":"+list.get(i).getId()+",");

            String actname = list.get(i).getActname().replace("\""," ").trim();
            buffer.append("\"actname\": \""+actname+"\",");

            String museumName = list.get(i).getMuseumName().replace("\"", " ").trim();
            buffer.append("\"museumName\":\""+museumName+"\",");

            buffer.append("\"time\":\""+simple.format(list.get(i).getTime())+"\",");

            String introduction = list.get(i).getIntroduction();
            introduction=introduction.replace("\n","");
            introduction=introduction.replace("\""," ").trim();
            buffer.append("\"introduction\":\""+introduction+"\",");

            buffer.append("\"photo\":\""+list.get(i).getPhoto()+"\"}");
            if (i!=size-1)
                buffer.append(",");
        }
        buffer.append("]}");
        String s1 = new String(buffer);
        out.print(s1);
    }

    public Activity create(HttpServletRequest request) {
        Activity activity = new Activity();
        activity.setId(Integer.parseInt(request.getParameter("id")));
        activity.setActname(request.getParameter("actname"));
        activity.setMuseumName(request.getParameter("museumName"));
        activity.setTime(Date.valueOf(request.getParameter("time")));
        activity.setIntroduction(request.getParameter("introduction"));
        activity.setPhoto(request.getParameter("photo"));
        return activity;
    }

    public Activity create2(HttpServletRequest request) {
        Activity activity = new Activity();
        activity.setActname(request.getParameter("actname"));
        activity.setMuseumName(request.getParameter("museumName"));
        activity.setTime(Date.valueOf(request.getParameter("time")));
        activity.setIntroduction(request.getParameter("introduction"));
        activity.setPhoto(request.getParameter("photo"));
        return activity;
    }






}
