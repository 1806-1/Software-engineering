package com.wenr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.wenr.model.Room;
import com.wenr.model.Student;
import com.wenr.util.DBUtil;

public class RoomDao {

	public ArrayList<Room> getAllRoom() {

		ArrayList<Room> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from room";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Room room = new Room();
				room.setQinshi(rs.getInt(1));
				room.setLouhao(rs.getInt(2));
				room.setRenshu(rs.getInt(3));
				room.setPhone(rs.getString(4));
				room.setRemainren(rs.getInt(5));
				room.setFee(rs.getInt(6));
				list.add(room);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

	public int checkroom(int louhao, int qinshi) {
		Connection conn = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			String sql1 = "select count(sid) from student where louhao=? and qinshi=?";
			pstmt1 = conn.prepareStatement(sql1);
			pstmt1.setInt(1, louhao);
			pstmt1.setInt(2, qinshi);
			rs = pstmt1.executeQuery();
			if (rs != null && rs.next()) {
				int b = rs.getInt("count(sid)");

				return b;
			} else
				return -1;

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return -1;
	}

	public boolean updateRoom(Room room) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			if (checkqinshi(room.getLouhao(), room.getQinshi())) {
				conn = DBUtil.getConnection();
				String sql = "update room set renshu=?,phone=? ,fee=? where qinshi=? and louhao=?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setInt(1, room.getRenshu());
				pstmt.setString(2, room.getPhone());
				pstmt.setInt(3, room.getFee());
				pstmt.setInt(4, room.getQinshi());
				pstmt.setInt(5, room.getLouhao());
				pstmt.executeUpdate();
			} else
				return false;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public Room getRoomById(int qinshi, int louhao) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select qinshi,louhao,renshu,phone,fee from room where qinshi = ? and louhao=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, qinshi);
			pstmt.setInt(2, louhao);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				Room room = new Room();
				room.setQinshi(rs.getInt(1));
				room.setLouhao(rs.getInt(2));
				room.setRenshu(rs.getInt(3));
				room.setPhone(rs.getString(4));
				room.setFee(rs.getInt(5));

				return room;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return null;
	}

	public boolean checkqinshi(int louhao, int qinshi) {

		Connection conn = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			String sql1 = "select fangjian from build where louhao=? and louceng=?";
			pstmt1 = conn.prepareStatement(sql1);
			pstmt1.setInt(1, louhao);
			int a = qinshi / 100;
			pstmt1.setInt(2, a);
			rs = pstmt1.executeQuery();
			if (rs != null && rs.next()) {
				int b = rs.getInt("fangjian");
				int i = qinshi;
				if (i % 100 <= b) {
					return true;
				} else
					return false;
			} else
				return false;

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public boolean addRoom(Room Room) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		try {
			conn = DBUtil.getConnection();

			if (checkqinshi(Room.getLouhao(), Room.getQinshi())) {
				String sql = "insert into Room(qinshi,louhao,renshu,phone,remainren,fee) values(?,?,?,?,?,?)";
				String sql1 = "insert into pay(qinshi,louhao,jine) values(?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt1 = conn.prepareStatement(sql1);
				pstmt.setInt(1, Room.getQinshi());
				pstmt.setInt(2, Room.getLouhao());
				pstmt.setInt(3, Room.getRenshu());
				pstmt.setString(4, Room.getPhone());
				pstmt.setInt(5, Room.getRemainren());
				pstmt.setInt(6, Room.getFee());
				pstmt1.setInt(1, Room.getQinshi());
				pstmt1.setInt(2, Room.getLouhao());
				pstmt1.setInt(3, Room.getFee());
				pstmt.executeUpdate();
				pstmt1.executeUpdate();
				return true;
			} else
				return false;

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public boolean deleteRoom(int qinshi, int louhao) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			if (checkroom(louhao, qinshi) == 0) {
				conn = DBUtil.getConnection();
				String sql = "delete from room where qinshi=? and louhao=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, qinshi);
				pstmt.setInt(2, louhao);
				pstmt.executeUpdate();
				return true;
			} else
				return false;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public ArrayList<Room> getRoomby(int qinshi, int louhao) {

		ArrayList<Room> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from room where qinshi = ? and louhao=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, qinshi);
			pstmt.setInt(2, louhao);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				Room room = new Room();
				room.setQinshi(rs.getInt(1));
				room.setLouhao(rs.getInt(2));
				room.setRenshu(rs.getInt(3));
				room.setPhone(rs.getString(4));
				room.setRemainren(rs.getInt(5));
				room.setFee(rs.getInt(6));
				list.add(room);
			} else
				return null;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

}
