package com.wenr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.wenr.model.Build;
import com.wenr.model.Room;
import com.wenr.util.DBUtil;

public class BuildDao {

	public ArrayList<Build> getAllBuild() {

		ArrayList<Build> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from build";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				Build build = new Build();
				build.setLouhao(rs.getInt(1));
				build.setLouceng(rs.getInt(2));
				build.setFangjian(rs.getInt(3));
				build.setAlllouceng(rs.getInt(4));
				build.setRemainfang(rs.getInt(5));
				build.setTime(rs.getString(6));
				list.add(build);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}

	public boolean addBuild(Build Build) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = DBUtil.getConnection();

			if (Build.getRemainfang() >= Build.getFangjian()
					&& Build.getAlllouceng() >= Build.getLouceng()) {
				String sql = "insert into Build(louhao,louceng,fangjian,alllouceng,remainfang,time) values(?,?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Build.getLouhao());
				pstmt.setInt(2, Build.getLouceng());
				pstmt.setInt(3, Build.getFangjian());
				pstmt.setInt(4, Build.getAlllouceng());
				pstmt.setInt(5, Build.getRemainfang());
				pstmt.setString(6, Build.getTime());
				pstmt.executeUpdate();
				return true;
			} else
				return false;

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public void updateBuild(Build build) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "update build set fangjian=?,alllouceng=? ,time=? where louceng=? and louhao=?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, build.getFangjian());
			pstmt.setInt(2, build.getAlllouceng());
			pstmt.setString(3, build.getTime());
			pstmt.setInt(4, build.getLouceng());
			pstmt.setInt(5, build.getLouhao());
			pstmt.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public boolean updatefang(int louhao) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select count(qinshi) from room where louhao=? and qinshi not in(select qinshi from student where louhao=?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, louhao);
			pstmt.setInt(2, louhao);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				int a = rs.getInt("count(qinshi)");
				String sql2 = "update build set remainfang=? where louhao=?";
				pstmt2 = conn.prepareStatement(sql2);
				pstmt2.setInt(1, a);
				pstmt2.setInt(2, louhao);
				pstmt2.executeUpdate();
				return true;
			} else
				return false;

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public void deleteBuild(int louhao, int louceng) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "delete from build where louhao=? and louceng=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, louhao);
			pstmt.setInt(2, louceng);
			pstmt.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public Build getBuildById(int louhao, int louceng) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select louhao,louceng,fangjian,alllouceng ,time  from build where louhao = ? and louceng=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, louhao);
			pstmt.setInt(2, louceng);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				Build build = new Build();
				build.setLouhao(rs.getInt(1));
				build.setLouceng(rs.getInt(2));
				build.setFangjian(rs.getInt(3));
				build.setAlllouceng(rs.getInt(4));
				// build.setRemainfang(rs.getInt(5));
				build.setTime(rs.getString(5));

				return build;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return null;
	}

	public ArrayList<Build> getBuildby(int louhao, int louceng) {

		ArrayList<Build> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			String sql = "select * from build where louhao = ? and louceng=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, louhao);
			pstmt.setInt(2, louceng);
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				Build build = new Build();
				build.setLouhao(rs.getInt(1));
				build.setLouceng(rs.getInt(2));
				build.setFangjian(rs.getInt(3));
				build.setAlllouceng(rs.getInt(4));
				build.setRemainfang(rs.getInt(5));
				build.setTime(rs.getString(6));
				list.add(build);
			} else
				return null;

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}
}
